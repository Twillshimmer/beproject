import { useAuth } from "@/contexts/AuthContext";

export function DashboardPage() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">
          Welcome back, {user?.full_name?.split(" ")[0]}
        </h1>
        <p className="text-sm text-slate-500">
          Signed in as <span className="font-medium">{user?.email}</span> ·{" "}
          <span className="capitalize">{user?.role.name}</span>
        </p>
      </div>

      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center">
        <p className="text-sm font-medium text-slate-700">
          Dashboard metrics are not implemented yet.
        </p>
        <p className="mt-1 text-sm text-slate-500">
          Employee, project, task, and integration statistics are delivered in
          Milestone 2 once the core data APIs land. Authentication and the
          application shell you're looking at now are complete and working.
        </p>
      </div>
    </div>
  );
}
