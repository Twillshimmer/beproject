import { NavLink } from "react-router-dom";
import { LayoutDashboard, Users, FolderKanban, Network, MessageSquareText, Repeat, PlugZap, ScrollText } from "lucide-react";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/employees", label: "Employees", icon: Users },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/knowledge-graph", label: "Knowledge Graph", icon: Network },
  { to: "/assistant", label: "AI Assistant", icon: MessageSquareText },
  { to: "/handover", label: "Handover", icon: Repeat },
  { to: "/integrations", label: "Integrations", icon: PlugZap },
  { to: "/audit-logs", label: "Audit Logs", icon: ScrollText },
];

export function Sidebar() {
  return (
    <aside className="hidden w-60 shrink-0 border-r border-slate-200 bg-white md:flex md:flex-col">
      <div className="px-5 py-5">
        <p className="text-sm font-semibold tracking-tight text-brand-700">
          Knowledge Continuity
        </p>
        <p className="text-xs text-slate-400">Enterprise Platform</p>
      </div>
      <nav className="flex-1 space-y-0.5 px-3">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                isActive
                  ? "bg-brand-50 text-brand-700"
                  : "text-slate-600 hover:bg-slate-100"
              }`
            }
          >
            <Icon size={17} strokeWidth={2} />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
