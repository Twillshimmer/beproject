export type RoleName = "admin" | "manager" | "employee";

export interface Role {
  id: string;
  name: RoleName;
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  is_active: boolean;
  role: Role;
  created_at: string;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
  user: User;
}
