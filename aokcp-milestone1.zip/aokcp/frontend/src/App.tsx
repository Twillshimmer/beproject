import { Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AppLayout } from "@/layouts/AppLayout";
import { LoginPage } from "@/pages/LoginPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { ComingSoonPage } from "@/components/ComingSoonPage";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route
              path="/employees"
              element={<ComingSoonPage title="Employees" milestone="Milestone 2" />}
            />
            <Route
              path="/projects"
              element={<ComingSoonPage title="Projects" milestone="Milestone 2" />}
            />
            <Route
              path="/knowledge-graph"
              element={<ComingSoonPage title="Knowledge Graph" milestone="Milestone 6" />}
            />
            <Route
              path="/assistant"
              element={<ComingSoonPage title="AI Assistant" milestone="Milestone 9" />}
            />
            <Route
              path="/handover"
              element={<ComingSoonPage title="Handover" milestone="Milestone 10" />}
            />
            <Route
              path="/integrations"
              element={<ComingSoonPage title="Integrations" milestone="Milestones 3 & 4" />}
            />
            <Route
              path="/audit-logs"
              element={<ComingSoonPage title="Audit Logs" milestone="Milestone 2" />}
            />
          </Route>
        </Route>

        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AuthProvider>
  );
}
