export function ComingSoonPage({ title, milestone }: { title: string; milestone: string }) {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-slate-900">{title}</h1>
      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center">
        <p className="text-sm font-medium text-slate-700">Not implemented yet</p>
        <p className="mt-1 text-sm text-slate-500">
          This feature is planned for {milestone}. See IMPLEMENTATION_STATUS.md
          for current progress.
        </p>
      </div>
    </div>
  );
}
