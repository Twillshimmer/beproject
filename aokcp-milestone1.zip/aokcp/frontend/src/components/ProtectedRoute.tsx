import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import type { RoleName } from "@/types/auth";

export function ProtectedRoute({ allowedRoles }: { allowedRoles?: RoleName[] }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center text-slate-500">
        Loading…
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  if (allowedRoles && !allowedRoles.includes(user.role.name)) {
    return (
      <div className="flex h-screen items-center justify-center text-slate-500">
        You do not have permission to view this page.
      </div>
    );
  }

  return <Outlet />;
}
