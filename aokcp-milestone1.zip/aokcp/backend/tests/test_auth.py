def register(client, email="jane@example.com", password="SecurePass123", name="Jane Doe"):
    return client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "full_name": name},
    )


def test_register_creates_user_and_returns_token(client):
    resp = register(client)
    assert resp.status_code == 201
    body = resp.json()
    assert body["access_token"]
    assert body["user"]["email"] == "jane@example.com"
    assert body["user"]["role"]["name"] == "employee"


def test_register_duplicate_email_rejected(client):
    register(client)
    resp = register(client)
    assert resp.status_code == 400


def test_register_rejects_short_password(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "x@example.com", "password": "short", "full_name": "X"},
    )
    assert resp.status_code == 422


def test_login_success(client):
    register(client)
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "jane@example.com", "password": "SecurePass123"},
    )
    assert resp.status_code == 200
    assert "access_token" in resp.json()


def test_login_wrong_password_rejected(client):
    register(client)
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "jane@example.com", "password": "WrongPassword"},
    )
    assert resp.status_code == 401


def test_login_nonexistent_user_rejected(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "nobody@example.com", "password": "whatever123"},
    )
    assert resp.status_code == 401


def test_me_requires_authentication(client):
    resp = client.get("/api/v1/auth/me")
    assert resp.status_code == 401


def test_me_returns_current_user_with_valid_token(client):
    token = register(client).json()["access_token"]
    resp = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == "jane@example.com"


def test_me_rejects_invalid_token(client):
    resp = client.get("/api/v1/auth/me", headers={"Authorization": "Bearer not-a-real-token"})
    assert resp.status_code == 401


def test_passwords_are_hashed_not_stored_plain(client, db_session):
    register(client)
    from app.models.user import User

    user = db_session.query(User).filter(User.email == "jane@example.com").first()
    assert user.hashed_password != "SecurePass123"
    assert user.hashed_password.startswith("$2b$")
