def test_health_endpoint_reports_postgres_healthy(client):
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["services"]["postgresql"] == "healthy"
    # Honest reporting: these are not yet integrated, and must say so.
    assert body["services"]["neo4j"] == "not_yet_integrated"
    assert body["services"]["chromadb"] == "not_yet_integrated"
