"""Seed baseline data: roles + one admin account so the platform is usable
immediately after `docker compose up`. Run with `python -m app.seed`.

More sample datasets (employees, projects, mock Jira/GitHub data, ...) are
added to this module in later milestones (M2+) rather than a separate script,
so there is one documented entrypoint for demo data.
"""
import logging

from app.auth.security import hash_password
from app.db.session import SessionLocal
from app.models.role import Role
from app.models.user import User

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aokcp.seed")

ROLES = ["admin", "manager", "employee"]
DEFAULT_ADMIN_EMAIL = "admin@aokcp.local"
DEFAULT_ADMIN_PASSWORD = "ChangeMe123!"


def seed_roles(db) -> dict[str, Role]:
    existing = {r.name: r for r in db.query(Role).all()}
    for name in ROLES:
        if name not in existing:
            role = Role(name=name, description=f"{name.capitalize()} role")
            db.add(role)
            existing[name] = role
    db.commit()
    return {r.name: r for r in db.query(Role).all()}


def seed_admin(db, roles: dict[str, Role]) -> None:
    if db.query(User).filter(User.email == DEFAULT_ADMIN_EMAIL).first():
        logger.info("Admin user already exists, skipping.")
        return
    admin = User(
        email=DEFAULT_ADMIN_EMAIL,
        hashed_password=hash_password(DEFAULT_ADMIN_PASSWORD),
        full_name="Platform Administrator",
        role=roles["admin"],
    )
    db.add(admin)
    db.commit()
    logger.info(
        "Created default admin: %s / %s (change this password immediately)",
        DEFAULT_ADMIN_EMAIL,
        DEFAULT_ADMIN_PASSWORD,
    )


def main() -> None:
    db = SessionLocal()
    try:
        roles = seed_roles(db)
        seed_admin(db, roles)
        logger.info("Seed complete.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
