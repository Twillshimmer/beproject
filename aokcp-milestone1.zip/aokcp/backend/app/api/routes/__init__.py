from fastapi import APIRouter

from app.api.routes import auth, health

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
# Additional routers (employees, projects, tasks, ...) are added here as
# their milestones land, per IMPLEMENTATION_STATUS.md.
