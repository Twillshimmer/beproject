from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db

router = APIRouter(tags=["health"])
settings = get_settings()


@router.get("/health")
def health(db: Session = Depends(get_db)):
    services: dict[str, str] = {}

    try:
        db.execute(text("SELECT 1"))
        services["postgresql"] = "healthy"
    except Exception as exc:  # pragma: no cover - defensive
        services["postgresql"] = f"unhealthy: {exc.__class__.__name__}"

    # Neo4j and ChromaDB clients land in Milestones 6/7. Until then we report
    # the true state instead of a fabricated "healthy".
    services["neo4j"] = "not_yet_integrated"
    services["chromadb"] = "not_yet_integrated"
    services["gemini"] = "configured" if settings.gemini_configured else "not_configured"

    overall = "healthy" if services["postgresql"] == "healthy" else "degraded"
    return {"status": overall, "services": services}
