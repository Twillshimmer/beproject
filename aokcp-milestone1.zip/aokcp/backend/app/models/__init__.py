"""Import every model here so Alembic's autogenerate and Base.metadata see
the full schema. Add new model modules as milestones introduce them."""
from app.models.role import Role  # noqa: F401
from app.models.user import User  # noqa: F401
