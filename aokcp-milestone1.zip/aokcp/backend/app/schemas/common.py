from pydantic import BaseModel


class ErrorResponse(BaseModel):
    """Consistent error envelope returned by every handled exception."""

    detail: str
    error_code: str | None = None
