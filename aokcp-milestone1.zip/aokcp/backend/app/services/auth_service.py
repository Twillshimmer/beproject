from sqlalchemy.orm import Session

from app.auth.jwt import create_access_token
from app.auth.security import hash_password, verify_password
from app.models.user import User
from app.repositories.user_repository import UserRepository


class AuthError(Exception):
    """Raised for expected auth failures (bad credentials, duplicate email)."""


class AuthService:
    DEFAULT_ROLE = "employee"

    def __init__(self, db: Session):
        self.db = db
        self.repo = UserRepository(db)

    def register(self, *, email: str, password: str, full_name: str) -> User:
        if self.repo.get_by_email(email):
            raise AuthError("An account with this email already exists")

        role = self.repo.get_role_by_name(self.DEFAULT_ROLE)
        if role is None:
            # Roles are seeded at startup/seed time; this guards against a
            # misconfigured environment rather than silently failing later.
            raise AuthError(
                "Default role is not configured on this server. Run the seed script."
            )

        user = self.repo.create(
            email=email,
            hashed_password=hash_password(password),
            full_name=full_name,
            role=role,
        )
        return user

    def authenticate(self, *, email: str, password: str) -> User:
        user = self.repo.get_by_email(email)
        if user is None or not verify_password(password, user.hashed_password):
            raise AuthError("Incorrect email or password")
        if not user.is_active:
            raise AuthError("This account has been deactivated")
        return user

    @staticmethod
    def issue_token(user: User) -> str:
        return create_access_token(subject=str(user.id), extra_claims={"role": user.role.name})
