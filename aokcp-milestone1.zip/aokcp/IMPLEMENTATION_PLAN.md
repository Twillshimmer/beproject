# Implementation Plan — AI-Powered Organizational Knowledge Continuity Platform

This document is the architectural source of truth. It is written before code and
updated only if an architectural decision changes. Day-to-day progress is tracked
in `IMPLEMENTATION_STATUS.md`, not here.

## 1. Problem Restatement

Organizations lose knowledge when people leave, transfer, or switch projects.
Knowledge is scattered across Jira, GitHub, documents, and people's heads. This
platform aggregates that knowledge into a queryable substrate (relational +
graph + vector) and exposes it through an AI assistant, handover generator,
onboarding generator, and knowledge-gap detector — all permission-aware and
all grounded in retrieved facts (no hallucinated org facts).

## 2. High-Level Architecture

```
React (Vite/TS) ── Axios/JWT ──> FastAPI ── SQLAlchemy ──> PostgreSQL (system of record)
                                     │
                                     ├── neo4j driver ──> Neo4j (relationship graph)
                                     ├── chromadb client ──> ChromaDB (embeddings)
                                     ├── httpx ──> Jira / GitHub (or Mock providers)
                                     └── google-genai ──> Gemini (chat + embeddings)
```

Layering inside the backend (strict): `routes` (HTTP only) → `services`
(business logic, orchestration) → `repositories` (DB access) → `models`.
Routes never touch the DB session directly for business rules; they call a
service. Services never import FastAPI request/response objects.

## 3. PostgreSQL Entity Model

Core tables (all have `id: UUID pk`, `created_at`, `updated_at`):

- **User**(email unique, hashed_password, full_name, role_id FK→Role, is_active,
  employee_id FK→Employee nullable)
- **Role**(name unique: admin/manager/employee, description)
- **Department**(name, description, manager_employee_id FK→Employee nullable)
- **Employee**(full_name, email unique, title, department_id FK, manager_id
  FK→Employee self, github_username, jira_account_id, status: active/left,
  hire_date, left_date nullable)
- **Project**(name, key unique (JIRA-style), description, department_id FK,
  status: active/inactive/archived, repository_url)
- **ProjectMember**(project_id FK, employee_id FK, role_on_project, joined_at,
  left_at nullable) — unique(project_id, employee_id)
- **Task**(project_id FK, external_id (Jira key) unique-per-source, title,
  description, status, priority, assignee_id FK→Employee nullable, type:
  task/bug/story, source: jira/manual, created_at_source, updated_at_source)
- **Bug**(same shape as Task but modelled distinctly per spec — implemented as
  a thin subtype table referencing Task.id with severity, resolution)
- **Document**(title, filename, file_path, file_type, uploaded_by FK→User,
  project_id FK nullable, department_id FK nullable, size_bytes, status:
  processing/processed/failed)
- **IntegrationConfig**(type: jira/github/hr/documents, mode: live/mock,
  config JSONB (non-secret fields only), is_enabled, last_synced_at)
- **SyncLog**(integration_type, status: success/partial/failed, started_at,
  finished_at, records_synced, errors JSONB, triggered_by FK→User)
- **AuditLog**(user_id FK nullable, action, resource_type, resource_id,
  metadata JSONB, status, created_at, ip_address nullable)
- **IdentityMapping**(external_system: jira/github, external_identifier,
  employee_id FK nullable, status: resolved/unresolved, resolved_by FK→User)

Relationships use FKs + indexes on all FK columns and on frequently filtered
columns (`status`, `email`, `external_id`). Alembic manages all schema
changes; no `create_all` in production path (dev bootstrap may use it as a
fallback only if no migrations have been run, clearly logged).

## 4. Neo4j Graph Model

Nodes: `Employee, Department, Project, Task, Bug, Repository, Commit,
PullRequest, Document, Module, Technology`. Every node carries a
`pg_id` property linking back to the Postgres row where applicable, so the
graph is a derived/synchronized view, not a second source of truth for core
identity.

Relationships (directed, as specified): `WORKS_IN, WORKED_ON, MEMBER_OF,
ASSIGNED_TO, CREATED, REVIEWED, HAS_TASK, HAS_BUG, HAS_REPOSITORY,
HAS_COMMIT, HAS_PULL_REQUEST, MODIFIES, USES, DOCUMENTED_BY, RELATED_TO,
DEPENDS_ON`.

Relationships are only created when the source data explicitly supports them
(e.g. `MODIFIES` from a commit's changed-files list; `USES` only when a
technology tag is present on a project/repo — never inferred from
free text without an extraction step that records provenance).

`GraphService` responsibilities: upsert node, upsert relationship, search
entities by label+text, neighborhood traversal (N hops, capped), employee
knowledge traversal (Employee → Project/Task/Bug/Repository/Technology),
technology ownership traversal (Technology → Employees via USES/MODIFIES),
dependency traversal (Module/Technology → DEPENDS_ON chain).

## 5. ChromaDB Collections

`documents, jira_issues, github_commits, pull_requests, project_summaries,
knowledge_chunks`. Each record: `id`, `embedding`, `document` (chunk text),
`metadata` = `{source_type, source_id, project_id, employee_id,
department_id, repository, document_id, created_at, updated_at, title,
author, url}`. Embedding function: Gemini embeddings if `GEMINI_API_KEY` is
set and reachable, else SentenceTransformers (`all-MiniLM-L6-v2`) local
fallback — selected once at startup and logged, never silently mixed within
one collection.

## 6. Hybrid Retrieval Pipeline

`HybridRetrievalService.retrieve(question, user, filters)`:
1. Preprocess (normalize, strip stopword noise for keyword pass).
2. Lightweight entity/intent detection: regex + DB lookup against known
   Employee names, Project keys/names, Technology names mentioned in the
   question (no heavy NLP model needed for this scope — documented as a
   deliberate simplification).
3. Vector retrieval: ChromaDB query across relevant collections, filtered by
   any detected project/employee/department metadata and by the requesting
   user's permission scope.
4. Graph retrieval: if an entity was detected, run the matching traversal
   (employee knowledge / project neighborhood / technology ownership /
   dependency) to pull structured facts.
5. Keyword/metadata filter pass over both result sets.
6. Ranking: weighted sum of normalized vector similarity, graph-hit boost,
   metadata match boost, recency decay — weights in config, documented.
7. Deduplicate by `(source_type, source_id)`.
8. Build a citation-tagged context block.
9. Send to Gemini with the grounding system prompt (see §7).
10. Return `{answer, citations[], retrieval_debug}`.

Permission enforcement happens at step 3/4 (query filters), not after the
fact — unauthorized content is never fetched, so it can never leak into the
prompt.

## 7. Gemini Service

Single service (`app/services/gemini/client.py`) wrapping the official
`google-genai` SDK. All prompts are built from templates that include the
retrieved context and an explicit instruction block: answer only from
supplied context; say "unavailable" when the context doesn't cover it;
separate "Retrieved facts" from "Recommendations"; include citations; respect
the permission-filtered context (nothing else to respect, since it was never
fetched). Functions: `answer_question`, `summarize_project`,
`summarize_employee_knowledge`, `generate_handover`, `generate_onboarding`,
`analyze_knowledge_gaps`. On failure (network/quota/parse), raise a typed
`GeminiUnavailableError` caught at the route layer → HTTP 503 with a clear
message; never fabricated as a 200.

## 8. AuthN/AuthZ

JWT (HS256) access tokens, `passlib[bcrypt]` hashing. `get_current_user`
FastAPI dependency decodes/validates the token and loads the user + role.
`require_role(*roles)` dependency factory for route-level RBAC.
Object-level checks (e.g. "manager can only see their own team's projects")
live in services, applied as query filters — this is what "not just hiding
frontend buttons" means concretely.

## 9. REST API Groups (`/api/v1`)

`/auth, /users, /employees, /departments, /projects, /tasks, /bugs,
/documents, /integrations, /integrations/jira, /integrations/github, /sync,
/knowledge-graph, /search, /assistant, /handover, /onboarding, /audit-logs,
/dashboard, /health`.

## 10. Frontend Architecture

Vite + React + TS + Tailwind + React Router. `AuthContext` holds the JWT and
current user, persisted in memory + localStorage token only (never the
password). `axios` instance with an interceptor attaching `Authorization`
and handling 401 → redirect to `/login`. Route guard component
`ProtectedRoute` wraps role-aware routes. Each feature folder owns its API
calls (`features/x/api.ts`), types, and page components — pages under
`pages/` compose feature components with the shared `AppLayout`
(sidebar + topbar).

## 11. Docker Compose Services

`postgres, neo4j, chromadb, backend, frontend`, each with health checks and
named volumes (`pgdata, neo4jdata, chromadata`). Backend depends on the three
data services being healthy before starting; frontend depends on backend.

## 12. Milestone Order

As specified in the brief, M1 → M11 (Auth/Docker → Core data → Jira →
GitHub → Processing → Neo4j → ChromaDB → Hybrid RAG → Gemini assistant →
Continuity features → Testing/deployment). Each milestone ends with a
runnable system and an `IMPLEMENTATION_STATUS.md` update.

## 13. Key Assumptions (documented per §45 of the brief)

- "Bug" is modeled as a Task subtype (shares lifecycle/assignee columns) to
  avoid duplicating the whole task schema — flagged here per the ambiguity
  rule rather than silently deciding.
- Entity/intent detection in retrieval is lexical (name/key matching against
  known DB entities), not a trained NER model — appropriate for the academic
  scope and fully explainable at a viva; documented as a limitation.
- Secrets (Jira token, GitHub token, Gemini key) live only in backend env
  vars, never in `IntegrationConfig.config` (that JSONB holds non-secret
  fields like base URL only).
