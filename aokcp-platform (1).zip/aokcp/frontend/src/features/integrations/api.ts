import { apiClient } from "@/services/apiClient";
import type {
  IdentityMappingEntry,
  IntegrationConfig,
  Paginated,
  SyncLogEntry,
} from "@/types/domain";

export async function listIntegrations(): Promise<IntegrationConfig[]> {
  const { data } = await apiClient.get<IntegrationConfig[]>("/integrations");
  return data;
}

export async function updateIntegration(
  type: string,
  updates: { is_enabled?: boolean }
): Promise<IntegrationConfig> {
  const { data } = await apiClient.patch<IntegrationConfig>(`/integrations/${type}`, updates);
  return data;
}

export async function triggerJiraSync(): Promise<SyncLogEntry> {
  const { data } = await apiClient.post<SyncLogEntry>("/integrations/jira/sync");
  return data;
}

export async function listSyncLogs(integrationType: string): Promise<SyncLogEntry[]> {
  const { data } = await apiClient.get<SyncLogEntry[]>(`/integrations/${integrationType}/sync-logs`);
  return data;
}

export async function listIdentityMappings(params: {
  external_system?: string;
  status_filter?: string;
  page?: number;
} = {}): Promise<Paginated<IdentityMappingEntry>> {
  const { data } = await apiClient.get<Paginated<IdentityMappingEntry>>(
    "/integrations/identity-mappings",
    { params: { ...params, page_size: 25 } }
  );
  return data;
}

export async function resolveIdentityMapping(
  mappingId: string,
  employeeId: string
): Promise<IdentityMappingEntry> {
  const { data } = await apiClient.patch<IdentityMappingEntry>(
    `/integrations/identity-mappings/${mappingId}/resolve`,
    { employee_id: employeeId }
  );
  return data;
}
