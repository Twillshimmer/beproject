import { useEffect, useState } from "react";
import { CheckCircle2, Loader2, PlugZap, RefreshCw, XCircle } from "lucide-react";
import {
  listIdentityMappings,
  listIntegrations,
  listSyncLogs,
  resolveIdentityMapping,
  triggerJiraSync,
  updateIntegration,
} from "@/features/integrations/api";
import { listEmployees } from "@/features/employees/api";
import type { Employee, IdentityMappingEntry, IntegrationConfig, SyncLogEntry } from "@/types/domain";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { getApiErrorMessage } from "@/utils/errors";

const INTEGRATION_LABELS: Record<string, string> = {
  jira: "Jira",
  github: "GitHub",
  hr: "HR / Employee Data",
  documents: "Documents",
};

function ModeBadge({ mode }: { mode: string }) {
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
        mode === "live" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"
      }`}
    >
      {mode.toUpperCase()}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    success: "bg-emerald-50 text-emerald-700",
    partial: "bg-amber-50 text-amber-700",
    failed: "bg-red-50 text-red-700",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${styles[status] ?? "bg-slate-100 text-slate-500"}`}>
      {status}
    </span>
  );
}

export function IntegrationsPage() {
  const [integrations, setIntegrations] = useState<IntegrationConfig[]>([]);
  const [jiraSyncLogs, setJiraSyncLogs] = useState<SyncLogEntry[]>([]);
  const [unresolved, setUnresolved] = useState<IdentityMappingEntry[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<{ text: string; ok: boolean } | null>(null);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<Record<string, string>>({});

  function refresh() {
    setIsLoading(true);
    setError(null);
    Promise.all([
      listIntegrations(),
      listSyncLogs("jira"),
      listIdentityMappings({ status_filter: "unresolved" }),
      listEmployees({ page_size: 100 }),
    ])
      .then(([ints, logs, mappings, emps]) => {
        setIntegrations(ints);
        setJiraSyncLogs(logs);
        setUnresolved(mappings.items);
        setEmployees(emps.items);
      })
      .catch((err) => setError(getApiErrorMessage(err, "Could not load integrations.")))
      .finally(() => setIsLoading(false));
  }

  useEffect(refresh, []);

  async function handleToggle(type: string, enabled: boolean) {
    await updateIntegration(type, { is_enabled: enabled });
    setIntegrations((prev) => prev.map((i) => (i.type === type ? { ...i, is_enabled: enabled } : i)));
  }

  async function handleJiraSync() {
    setIsSyncing(true);
    setSyncMessage(null);
    try {
      const log = await triggerJiraSync();
      setSyncMessage({
        text: `Sync ${log.status}: ${log.records_synced} record(s) synced.`,
        ok: log.status !== "failed",
      });
      refresh();
    } catch (err) {
      setSyncMessage({ text: getApiErrorMessage(err, "Sync failed."), ok: false });
    } finally {
      setIsSyncing(false);
    }
  }

  async function handleResolve(mappingId: string) {
    const employeeId = selectedEmployee[mappingId];
    if (!employeeId) return;
    setResolvingId(mappingId);
    try {
      await resolveIdentityMapping(mappingId, employeeId);
      setUnresolved((prev) => prev.filter((m) => m.id !== mappingId));
    } finally {
      setResolvingId(null);
    }
  }

  if (isLoading) return <SkeletonRows count={4} />;

  if (error) {
    return <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-xl font-semibold text-slate-900">Integrations</h1>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {integrations.map((integration) => (
          <div key={integration.id} className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <PlugZap size={16} className="text-slate-400" />
                <p className="font-medium text-slate-800">{INTEGRATION_LABELS[integration.type]}</p>
              </div>
              <ModeBadge mode={integration.mode} />
            </div>
            <p className="mt-2 text-xs text-slate-400">
              {integration.last_synced_at
                ? `Last synced ${new Date(integration.last_synced_at).toLocaleString()}`
                : "Never synced"}
            </p>
            <label className="mt-3 flex items-center gap-2 text-xs text-slate-500">
              <input
                type="checkbox"
                checked={integration.is_enabled}
                onChange={(e) => handleToggle(integration.type, e.target.checked)}
              />
              Enabled
            </label>
            {integration.type === "jira" && (
              <button
                onClick={handleJiraSync}
                disabled={isSyncing}
                className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-700 disabled:opacity-60"
              >
                {isSyncing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
                Sync now
              </button>
            )}
          </div>
        ))}
      </div>

      {syncMessage && (
        <div
          className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${
            syncMessage.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
          }`}
        >
          {syncMessage.ok ? <CheckCircle2 size={15} /> : <XCircle size={15} />}
          {syncMessage.text}
        </div>
      )}

      <div>
        <h2 className="mb-2 text-sm font-semibold text-slate-700">Jira sync history</h2>
        {jiraSyncLogs.length === 0 ? (
          <EmptyState title="No syncs yet" description="Trigger a sync above to see history here." />
        ) : (
          <div className="rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Started</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Records</th>
                  <th className="px-4 py-3 font-medium">Errors</th>
                </tr>
              </thead>
              <tbody>
                {jiraSyncLogs.map((log) => (
                  <tr key={log.id} className="border-b border-slate-50 last:border-0">
                    <td className="px-4 py-3 text-slate-500">{new Date(log.started_at).toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={log.status} />
                    </td>
                    <td className="px-4 py-3 text-slate-700">{log.records_synced}</td>
                    <td className="px-4 py-3 text-slate-400">{log.errors.length || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-2 text-sm font-semibold text-slate-700">
          Unresolved identities ({unresolved.length})
        </h2>
        <p className="mb-2 text-xs text-slate-400">
          These Jira accounts couldn't be automatically matched to an employee by email. Link
          each one manually below.
        </p>
        {unresolved.length === 0 ? (
          <EmptyState title="No unresolved identities" description="Every synced identity is linked to an employee." />
        ) : (
          <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
            {unresolved.map((mapping) => (
              <div key={mapping.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm">
                <div>
                  <p className="font-medium text-slate-800">{mapping.external_identifier}</p>
                  <p className="text-xs uppercase text-slate-400">{mapping.external_system}</p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={selectedEmployee[mapping.id] ?? ""}
                    onChange={(e) =>
                      setSelectedEmployee((prev) => ({ ...prev, [mapping.id]: e.target.value }))
                    }
                    className="rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
                  >
                    <option value="">Select employee…</option>
                    {employees.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.full_name} ({e.email})
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => handleResolve(mapping.id)}
                    disabled={!selectedEmployee[mapping.id] || resolvingId === mapping.id}
                    className="rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-700 disabled:opacity-50"
                  >
                    {resolvingId === mapping.id ? "Linking…" : "Link"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">
        GitHub sync (repositories, commits, pull requests, contributors) is
        planned for Milestone 4.
      </div>
    </div>
  );
}
