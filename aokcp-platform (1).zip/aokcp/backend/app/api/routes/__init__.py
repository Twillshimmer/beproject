from fastapi import APIRouter

from app.api.routes import (
    audit_logs,
    auth,
    bugs,
    dashboard,
    departments,
    documents,
    employees,
    health,
    integrations,
    projects,
    tasks,
)

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(departments.router)
api_router.include_router(employees.router)
api_router.include_router(projects.router)
api_router.include_router(tasks.router)
api_router.include_router(bugs.router)
api_router.include_router(documents.router)
api_router.include_router(integrations.router)
api_router.include_router(audit_logs.router)
api_router.include_router(dashboard.router)
# Jira sync/identity-mapping endpoints live inside integrations.router
# (POST /integrations/jira/sync, /integrations/identity-mappings) rather
# than a separate module, since they share the IntegrationConfig/SyncLog
# resources. Additional routers (github, knowledge-graph, search, assistant,
# handover, onboarding) are added here as their milestones land.
