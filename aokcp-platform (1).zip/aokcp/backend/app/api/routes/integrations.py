import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth.dependencies import require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.identity_mapping import (
    IdentityMappingOut,
    IdentityMappingResolve,
    PaginatedIdentityMappings,
)
from app.schemas.integration import IntegrationConfigOut, IntegrationConfigUpdate, SyncLogOut
from app.schemas.pagination import PageParams, page_params
from app.services.identity_mapping_service import (
    IdentityMappingError,
    IdentityMappingNotFoundError,
    IdentityMappingService,
)
from app.services.integration_service import IntegrationService
from app.services.jira.sync_service import JiraSyncService

router = APIRouter(prefix="/integrations", tags=["integrations"])


# --- Static sub-paths registered before the dynamic /{integration_type}
# routes below, so "jira"/"identity-mappings" are never swallowed as a
# path parameter value. ---

@router.post("/jira/sync", response_model=SyncLogOut, status_code=status.HTTP_201_CREATED)
def trigger_jira_sync(db: Session = Depends(get_db), actor: User = Depends(require_role("admin"))):
    """Runs against the real Jira Cloud API if JIRA_BASE_URL/EMAIL/API_TOKEN
    are configured, otherwise against MockJiraClient. The resulting SyncLog
    always records which happened via the IntegrationConfig.mode it sets."""
    return JiraSyncService(db).sync(actor=actor)


@router.get("/identity-mappings", response_model=PaginatedIdentityMappings)
def list_identity_mappings(
    external_system: str | None = None,
    status_filter: str | None = None,
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(require_role("admin")),
):
    items, total = IdentityMappingService(db).search(
        external_system=external_system, status=status_filter,
        offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedIdentityMappings(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size
    )


@router.patch("/identity-mappings/{mapping_id}/resolve", response_model=IdentityMappingOut)
def resolve_identity_mapping(
    mapping_id: uuid.UUID, payload: IdentityMappingResolve, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        return IdentityMappingService(db).resolve(
            actor=actor, mapping_id=mapping_id, employee_id=payload.employee_id
        )
    except IdentityMappingNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except IdentityMappingError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


# --- Generic integration config routes (dynamic path — must come after the
# static routes above). ---

@router.get("", response_model=list[IntegrationConfigOut])
def list_integrations(db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    return IntegrationService(db).list_integrations()


@router.get("/{integration_type}", response_model=IntegrationConfigOut)
def get_integration(
    integration_type: str, db: Session = Depends(get_db), _: User = Depends(require_role("admin"))
):
    entry = IntegrationService(db).get_integration(integration_type)
    if entry is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found")
    return entry


@router.patch("/{integration_type}", response_model=IntegrationConfigOut)
def update_integration(
    integration_type: str, payload: IntegrationConfigUpdate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    return IntegrationService(db).update_integration(
        actor=actor, integration_type=integration_type, **payload.model_dump()
    )


@router.get("/{integration_type}/sync-logs", response_model=list[SyncLogOut])
def list_sync_logs(
    integration_type: str, pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db), _: User = Depends(require_role("admin")),
):
    items, _total = IntegrationService(db).list_sync_logs(
        integration_type=integration_type, offset=pagination.offset, limit=pagination.page_size
    )
    return items
