import uuid

from sqlalchemy.orm import Session

from app.models.identity_mapping import IdentityMapping
from app.models.user import User
from app.repositories.employee_repository import EmployeeRepository
from app.repositories.identity_mapping_repository import IdentityMappingRepository
from app.services.audit_service import AuditService


class IdentityMappingError(Exception):
    pass


class IdentityMappingNotFoundError(IdentityMappingError):
    pass


class IdentityMappingService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = IdentityMappingRepository(db)
        self.employee_repo = EmployeeRepository(db)
        self.audit = AuditService(db)

    def search(self, **kwargs) -> tuple[list[IdentityMapping], int]:
        return self.repo.search(**kwargs)

    def resolve(self, *, actor: User, mapping_id: uuid.UUID, employee_id: uuid.UUID) -> IdentityMapping:
        mapping = self.repo.get_by_id(mapping_id)
        if mapping is None:
            raise IdentityMappingNotFoundError("Identity mapping not found")
        if self.employee_repo.get(employee_id) is None:
            raise IdentityMappingError("Employee not found")

        mapping = self.repo.resolve_manually(mapping, employee_id=employee_id, resolved_by=actor.id)
        self.audit.log(
            user_id=actor.id, action="identity_mapping.resolve", resource_type="identity_mapping",
            resource_id=str(mapping.id),
            metadata={
                "external_system": mapping.external_system,
                "external_identifier": mapping.external_identifier,
                "employee_id": str(employee_id),
            },
        )
        return mapping
