from abc import ABC, abstractmethod

from app.services.jira.schemas import JiraFetchResult


class JiraClientBase(ABC):
    """Both `JiraClient` (real) and `MockJiraClient` implement this, so
    `JiraSyncService` can treat them interchangeably."""

    @abstractmethod
    def fetch_all(self) -> JiraFetchResult:
        """Fetch every project and issue this integration should sync.
        Raises `JiraClientError` on failure — never returns partial silent
        data on error."""
        raise NotImplementedError


class JiraClientError(Exception):
    """Raised for any Jira connectivity/auth/parsing failure. The sync
    service catches this and records it on the SyncLog rather than letting
    it crash the request."""
