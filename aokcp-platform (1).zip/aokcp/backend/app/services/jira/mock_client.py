"""Mock Jira data provider used whenever JIRA_BASE_URL/EMAIL/API_TOKEN are
not configured, so the full sync pipeline (Project/Task/Bug upsert, identity
mapping, SyncLog) is demonstrable with zero external credentials. The shape
mirrors what the real client produces (JiraFetchResult) so the sync service
never needs to know which one it's using.

Deliberately includes one issue assigned to a Jira account with no matching
Employee email, so the identity-mapping "unresolved" flow is exercised too.
"""
from datetime import datetime, timezone

from app.services.jira.base import JiraClientBase
from app.services.jira.schemas import JiraAssignee, JiraFetchResult, JiraIssue, JiraProject

_NOW = datetime.now(timezone.utc)


class MockJiraClient(JiraClientBase):
    def fetch_all(self) -> JiraFetchResult:
        projects = [
            JiraProject(key="PAY", name="Payment Platform", description="Payments processing and reconciliation"),
            JiraProject(key="NOTIF", name="Notification Service", description="Multi-channel notification delivery"),
            JiraProject(key="MOBILE", name="Mobile App", description="Customer-facing mobile application"),
        ]

        alicia = JiraAssignee(account_id="acc-alicia", email="alicia.ferreira@aokcp.demo", display_name="Alicia Ferreira")
        daniel = JiraAssignee(account_id="acc-daniel", email="daniel.osei@aokcp.demo", display_name="Daniel Osei")
        # Deliberately no matching Employee — exercises the unresolved
        # identity mapping path an admin must resolve manually.
        contractor = JiraAssignee(account_id="acc-ext-9f21", email="r.contractor@external-agency.example", display_name="R. Contractor")

        issues = [
            JiraIssue(
                key="PAY-101", project_key="PAY", summary="Reconcile settlement report mismatches",
                description="Nightly reconciliation job reports mismatches for ~2% of settlements.",
                issue_type="Task", priority="high", status="In Progress", assignee=alicia,
                created=_NOW, updated=_NOW,
            ),
            JiraIssue(
                key="PAY-104", project_key="PAY", summary="Duplicate charge on retried webhook",
                description="Payment provider webhook retries can create a second charge if idempotency key is missing.",
                issue_type="Bug", priority="high", status="Open", assignee=alicia,
                created=_NOW, updated=_NOW,
            ),
            JiraIssue(
                key="PAY-107", project_key="PAY", summary="Add rate limiting to public charge API",
                description=None, issue_type="Story", priority="medium", status="Open", assignee=daniel,
                created=_NOW, updated=_NOW,
            ),
            JiraIssue(
                key="NOTIF-52", project_key="NOTIF", summary="Migrate SMS provider integration",
                description="Move from legacy SMS gateway to the new provider contract.",
                issue_type="Task", priority="medium", status="Open", assignee=daniel,
                created=_NOW, updated=_NOW,
            ),
            JiraIssue(
                key="MOBILE-12", project_key="MOBILE", summary="Push notification opt-in screen crashes on Android 14",
                description="Crash reported on Pixel 8 devices when opening notification settings.",
                issue_type="Bug", priority="critical", status="Open", assignee=contractor,
                created=_NOW, updated=_NOW,
            ),
            JiraIssue(
                key="MOBILE-15", project_key="MOBILE", summary="Add biometric login support",
                description=None, issue_type="Story", priority="low", status="Open", assignee=None,
                created=_NOW, updated=_NOW,
            ),
        ]

        return JiraFetchResult(projects=projects, issues=issues)
