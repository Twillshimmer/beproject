import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.task import Task
from app.models.user import User
from app.repositories.employee_repository import EmployeeRepository
from app.repositories.identity_mapping_repository import IdentityMappingRepository
from app.repositories.integration_repository import IntegrationConfigRepository
from app.repositories.project_repository import ProjectRepository
from app.repositories.sync_log_repository import SyncLogRepository
from app.repositories.task_repository import BugRepository, TaskRepository
from app.services.audit_service import AuditService
from app.services.jira.base import JiraClientBase, JiraClientError
from app.services.jira.client import JiraClient
from app.services.jira.mock_client import MockJiraClient
from app.services.jira.schemas import JiraFetchResult, JiraIssue

settings = get_settings()

# Jira issue type names -> our internal Task.type values.
ISSUE_TYPE_MAP = {"bug": "bug", "story": "story", "task": "task"}


class JiraSyncService:
    def __init__(self, db: Session):
        self.db = db
        self.project_repo = ProjectRepository(db)
        self.task_repo = TaskRepository(db)
        self.bug_repo = BugRepository(db)
        self.employee_repo = EmployeeRepository(db)
        self.identity_repo = IdentityMappingRepository(db)
        self.integration_repo = IntegrationConfigRepository(db)
        self.sync_log_repo = SyncLogRepository(db)
        self.audit = AuditService(db)

    def _get_client(self) -> tuple[JiraClientBase, str]:
        if settings.jira_configured:
            return JiraClient(), "live"
        return MockJiraClient(), "mock"

    def sync(self, *, actor: User):
        started_at = datetime.now(timezone.utc)
        client, mode = self._get_client()
        errors: list[dict] = []
        records_synced = 0

        try:
            result = client.fetch_all()
        except JiraClientError as exc:
            log = self.sync_log_repo.create(
                integration_type="jira", status="failed", started_at=started_at,
                finished_at=datetime.now(timezone.utc), records_synced=0,
                errors=[{"message": str(exc)}], triggered_by=actor.id,
            )
            self.audit.log(
                user_id=actor.id, action="integration.sync", resource_type="integration_config",
                resource_id="jira", metadata={"mode": mode, "status": "failed"}, status="failed",
            )
            return log

        try:
            records_synced += self._upsert_projects(result)
            records_synced += self._upsert_issues(result.issues, errors)
        except Exception as exc:  # defensive: a partial sync is still logged, not silently lost
            errors.append({"message": f"Unexpected error during sync: {exc}"})

        status = "success" if not errors else ("partial" if records_synced > 0 else "failed")
        log = self.sync_log_repo.create(
            integration_type="jira", status=status, started_at=started_at,
            finished_at=datetime.now(timezone.utc), records_synced=records_synced,
            errors=errors, triggered_by=actor.id,
        )

        self.integration_repo.upsert(type="jira", mode=mode)
        self.integration_repo.update(
            self.integration_repo.get_by_type("jira"), last_synced_at=log.finished_at
        )

        self.audit.log(
            user_id=actor.id, action="integration.sync", resource_type="integration_config",
            resource_id="jira", metadata={"mode": mode, "status": status, "records_synced": records_synced},
            status="success" if status != "failed" else "failed",
        )
        return log

    def _upsert_projects(self, result: JiraFetchResult) -> int:
        count = 0
        for jp in result.projects:
            existing = self.project_repo.get_by_key(jp.key)
            if existing is None:
                self.project_repo.create(
                    name=jp.name, key=jp.key, description=jp.description, status="active"
                )
                count += 1
            elif jp.description and existing.description != jp.description:
                self.project_repo.update(existing, description=jp.description)
                count += 1
        return count

    def _upsert_issues(self, issues: list[JiraIssue], errors: list[dict]) -> int:
        count = 0
        for issue in issues:
            try:
                count += self._upsert_one_issue(issue)
            except Exception as exc:
                errors.append({"issue_key": issue.key, "message": str(exc)})
        return count

    def _upsert_one_issue(self, issue: JiraIssue) -> int:
        project = self.project_repo.get_by_key(issue.project_key)
        if project is None:
            raise ValueError(f"No local project found for Jira project key '{issue.project_key}'")

        assignee_id = self._resolve_assignee(issue)
        task_type = ISSUE_TYPE_MAP.get(issue.issue_type.lower(), "task")

        existing = self._find_task_by_external_id(issue.key)
        if existing:
            self.task_repo.update(
                existing, title=issue.summary, description=issue.description,
                status=issue.status.lower().replace(" ", "_"), priority=issue.priority,
                assignee_id=assignee_id,
            )
            existing.updated_at_source = issue.updated
            self.db.commit()
            task = existing
        else:
            task = self.task_repo.create(
                project_id=project.id, external_id=issue.key, title=issue.summary,
                description=issue.description, status=issue.status.lower().replace(" ", "_"),
                priority=issue.priority, type=task_type, source="jira", assignee_id=assignee_id,
                created_at_source=issue.created, updated_at_source=issue.updated,
            )

        if task_type == "bug" and task.bug is None:
            self.bug_repo.create(task_id=task.id, severity=issue.priority)
            self.db.refresh(task)

        return 1

    def _find_task_by_external_id(self, external_id: str) -> Task | None:
        stmt = select(Task).where(Task.source == "jira", Task.external_id == external_id)
        return self.db.execute(stmt).scalar_one_or_none()

    def _resolve_assignee(self, issue: JiraIssue) -> uuid.UUID | None:
        """Links a Jira assignee to an Employee by email when possible, and
        always records the identity mapping (resolved or not) so unresolved
        identities are visible to an admin — see IdentityMapping."""
        if issue.assignee is None:
            return None

        employee = None
        if issue.assignee.email:
            employee = self.employee_repo.get_by_email(issue.assignee.email)

        mapping_status = "resolved" if employee else "unresolved"
        self.identity_repo.upsert(
            external_system="jira",
            external_identifier=issue.assignee.account_id,
            employee_id=employee.id if employee else None,
            status=mapping_status,
        )
        return employee.id if employee else None
