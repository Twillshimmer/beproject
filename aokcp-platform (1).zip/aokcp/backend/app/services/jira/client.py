"""Real Jira Cloud REST API v3 client. Requires JIRA_BASE_URL, JIRA_EMAIL,
JIRA_API_TOKEN to be set (see app/core/config.py). This has not been
exercised against a live Jira instance in development — it is written
against the documented Jira Cloud REST API v3 shapes, but treat it as
unverified until it's run against a real site. See IMPLEMENTATION_STATUS.md.
"""
from datetime import datetime

import httpx

from app.core.config import get_settings
from app.services.jira.base import JiraClientBase, JiraClientError
from app.services.jira.schemas import JiraAssignee, JiraFetchResult, JiraIssue, JiraProject

settings = get_settings()

# Jira's priority names vary by instance configuration; this maps the common
# defaults to our internal low/medium/high/critical scale. Anything unknown
# falls back to "medium" rather than raising, since priority naming is
# site-configurable and shouldn't fail the whole sync.
PRIORITY_MAP = {
    "lowest": "low", "low": "low",
    "medium": "medium",
    "high": "high",
    "highest": "critical", "critical": "critical", "blocker": "critical",
}


class JiraClient(JiraClientBase):
    def __init__(self):
        if not settings.jira_configured:
            raise JiraClientError(
                "Jira is not configured (JIRA_BASE_URL/JIRA_EMAIL/JIRA_API_TOKEN missing)"
            )
        self.base_url = settings.JIRA_BASE_URL.rstrip("/")
        self.auth = (settings.JIRA_EMAIL, settings.JIRA_API_TOKEN)

    def fetch_all(self) -> JiraFetchResult:
        try:
            with httpx.Client(base_url=self.base_url, auth=self.auth, timeout=30.0) as client:
                projects = self._fetch_projects(client)
                issues: list[JiraIssue] = []
                for project in projects:
                    issues.extend(self._fetch_issues(client, project.key))
                return JiraFetchResult(projects=projects, issues=issues)
        except httpx.HTTPError as exc:
            raise JiraClientError(f"Jira request failed: {exc}") from exc

    def _fetch_projects(self, client: httpx.Client) -> list[JiraProject]:
        resp = client.get("/rest/api/3/project/search")
        resp.raise_for_status()
        data = resp.json()
        return [
            JiraProject(key=p["key"], name=p["name"], description=p.get("description"))
            for p in data.get("values", [])
        ]

    def _fetch_issues(self, client: httpx.Client, project_key: str) -> list[JiraIssue]:
        issues: list[JiraIssue] = []
        start_at = 0
        page_size = 50
        while True:
            resp = client.get(
                "/rest/api/3/search",
                params={
                    "jql": f"project={project_key}",
                    "startAt": start_at,
                    "maxResults": page_size,
                    "fields": "summary,description,issuetype,priority,status,assignee,created,updated",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            for raw in data.get("issues", []):
                issues.append(self._parse_issue(raw, project_key))
            start_at += page_size
            if start_at >= data.get("total", 0):
                break
        return issues

    @staticmethod
    def _parse_issue(raw: dict, project_key: str) -> JiraIssue:
        fields = raw["fields"]
        assignee_raw = fields.get("assignee")
        assignee = None
        if assignee_raw:
            assignee = JiraAssignee(
                account_id=assignee_raw["accountId"],
                email=assignee_raw.get("emailAddress"),
                display_name=assignee_raw.get("displayName", "Unknown"),
            )
        priority_name = (fields.get("priority") or {}).get("name", "medium").lower()
        return JiraIssue(
            key=raw["key"],
            project_key=project_key,
            summary=fields.get("summary", "(no summary)"),
            description=_extract_plain_text(fields.get("description")),
            issue_type=(fields.get("issuetype") or {}).get("name", "Task"),
            priority=PRIORITY_MAP.get(priority_name, "medium"),
            status=(fields.get("status") or {}).get("name", "Open"),
            assignee=assignee,
            created=datetime.fromisoformat(fields["created"]),
            updated=datetime.fromisoformat(fields["updated"]),
        )


def _extract_plain_text(adf_description) -> str | None:
    """Jira Cloud descriptions are Atlassian Document Format (nested JSON),
    not plain text. This extracts a best-effort plain-text rendering rather
    than storing raw ADF JSON as if it were readable text."""
    if not adf_description:
        return None
    if isinstance(adf_description, str):
        return adf_description
    parts: list[str] = []

    def walk(node):
        if isinstance(node, dict):
            if node.get("type") == "text":
                parts.append(node.get("text", ""))
            for child in node.get("content", []):
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)

    walk(adf_description)
    return " ".join(parts).strip() or None
