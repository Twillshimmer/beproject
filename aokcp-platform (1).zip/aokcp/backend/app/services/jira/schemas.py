"""Normalized shapes both the real and mock Jira clients return, so the sync
service never has to know which one it's talking to."""
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class JiraAssignee:
    account_id: str
    email: str | None
    display_name: str


@dataclass
class JiraIssue:
    key: str  # e.g. "PAY-101"
    project_key: str
    summary: str
    description: str | None
    issue_type: str  # Task | Story | Bug
    priority: str  # low | medium | high | critical
    status: str
    assignee: JiraAssignee | None
    created: datetime
    updated: datetime


@dataclass
class JiraProject:
    key: str
    name: str
    description: str | None = None


@dataclass
class JiraFetchResult:
    projects: list[JiraProject] = field(default_factory=list)
    issues: list[JiraIssue] = field(default_factory=list)
