import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.identity_mapping import IdentityMapping


class IdentityMappingRepository:
    def __init__(self, db: Session):
        self.db = db

    def get(self, external_system: str, external_identifier: str) -> IdentityMapping | None:
        stmt = select(IdentityMapping).where(
            IdentityMapping.external_system == external_system,
            IdentityMapping.external_identifier == external_identifier,
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def upsert(
        self, *, external_system: str, external_identifier: str,
        employee_id: uuid.UUID | None, status: str,
    ) -> IdentityMapping:
        existing = self.get(external_system, external_identifier)
        if existing:
            # Never downgrade a manually-resolved mapping back to unresolved
            # just because a later sync run didn't independently find the
            # employee — a human's resolution takes precedence.
            if existing.status == "resolved" and status == "unresolved":
                return existing
            existing.employee_id = employee_id or existing.employee_id
            existing.status = status
            self.db.commit()
            self.db.refresh(existing)
            return existing
        row = IdentityMapping(
            external_system=external_system, external_identifier=external_identifier,
            employee_id=employee_id, status=status,
        )
        self.db.add(row)
        self.db.commit()
        self.db.refresh(row)
        return row

    def search(
        self, *, external_system: str | None = None, status: str | None = None,
        offset: int = 0, limit: int = 20,
    ) -> tuple[list[IdentityMapping], int]:
        stmt = select(IdentityMapping)
        if external_system:
            stmt = stmt.where(IdentityMapping.external_system == external_system)
        if status:
            stmt = stmt.where(IdentityMapping.status == status)
        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(IdentityMapping.created_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def get_by_id(self, mapping_id: uuid.UUID) -> IdentityMapping | None:
        return self.db.get(IdentityMapping, mapping_id)

    def resolve_manually(
        self, mapping: IdentityMapping, *, employee_id: uuid.UUID, resolved_by: uuid.UUID
    ) -> IdentityMapping:
        mapping.employee_id = employee_id
        mapping.status = "resolved"
        mapping.resolved_by = resolved_by
        self.db.commit()
        self.db.refresh(mapping)
        return mapping
