import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.schemas.employee import EmployeeOut


class IdentityMappingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    external_system: str
    external_identifier: str
    employee_id: uuid.UUID | None
    employee: EmployeeOut | None = None
    status: str
    created_at: datetime


class PaginatedIdentityMappings(BaseModel):
    items: list[IdentityMappingOut]
    total: int
    page: int
    page_size: int


class IdentityMappingResolve(BaseModel):
    employee_id: uuid.UUID
