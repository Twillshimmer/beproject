def _seed_projects(client, admin):
    """PAY and NOTIF match the mock Jira project keys so issues attach to
    existing projects; MOBILE does not exist yet, so the sync should create
    it (exercising project auto-creation from Jira)."""
    client.post("/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin)
    client.post("/api/v1/projects", json={"name": "Notification Service", "key": "NOTIF"}, headers=admin)


def _seed_employee(client, admin, full_name="Alicia Ferreira", email="alicia.ferreira@aokcp.demo"):
    return client.post(
        "/api/v1/employees", json={"full_name": full_name, "email": email}, headers=admin
    ).json()


def test_non_admin_cannot_trigger_jira_sync(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post("/api/v1/integrations/jira/sync", headers=headers)
    assert resp.status_code == 403


def test_jira_sync_runs_in_mock_mode_without_credentials(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    _seed_employee(client, admin)

    resp = client.post("/api/v1/integrations/jira/sync", headers=admin)
    assert resp.status_code == 201
    body = resp.json()
    assert body["integration_type"] == "jira"
    assert body["status"] in ("success", "partial")
    assert body["records_synced"] > 0

    integration = client.get("/api/v1/integrations/jira", headers=admin).json()
    assert integration["mode"] == "mock"
    assert integration["last_synced_at"] is not None


def test_jira_sync_creates_missing_project(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)  # MOBILE deliberately not seeded
    _seed_employee(client, admin)

    client.post("/api/v1/integrations/jira/sync", headers=admin)

    resp = client.get("/api/v1/projects?q=Mobile", headers=admin)
    body = resp.json()
    assert body["total"] == 1
    assert body["items"][0]["key"] == "MOBILE"


def test_jira_sync_creates_tasks_and_bugs_and_links_known_employee(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    alicia = _seed_employee(client, admin)

    client.post("/api/v1/integrations/jira/sync", headers=admin)

    tasks = client.get("/api/v1/tasks?assignee_id=" + alicia["id"], headers=admin).json()
    assert tasks["total"] >= 1
    assert any(t["external_id"] == "PAY-101" for t in tasks["items"])

    bugs = client.get("/api/v1/bugs", headers=admin).json()
    assert any(b["task"]["external_id"] == "PAY-104" for b in bugs["items"])


def test_jira_sync_is_idempotent(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    _seed_employee(client, admin)

    client.post("/api/v1/integrations/jira/sync", headers=admin)
    project_id = client.get("/api/v1/projects?q=Payment", headers=admin).json()["items"][0]["id"]
    tasks_after_first = client.get(f"/api/v1/tasks?project_id={project_id}", headers=admin).json()["total"]

    client.post("/api/v1/integrations/jira/sync", headers=admin)
    tasks_after_second = client.get(f"/api/v1/tasks?project_id={project_id}", headers=admin).json()["total"]

    assert tasks_after_first == tasks_after_second


def test_jira_sync_records_unresolved_identity_for_unknown_assignee(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    _seed_employee(client, admin)

    client.post("/api/v1/integrations/jira/sync", headers=admin)

    resp = client.get("/api/v1/integrations/identity-mappings?status_filter=unresolved", headers=admin)
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] >= 1
    assert any(m["external_identifier"] == "acc-ext-9f21" for m in body["items"])


def test_admin_can_manually_resolve_an_identity_mapping(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    contractor_employee = _seed_employee(client, admin, "R. Contractor", "r.contractor@corp-internal.example")

    client.post("/api/v1/integrations/jira/sync", headers=admin)
    unresolved = client.get(
        "/api/v1/integrations/identity-mappings?status_filter=unresolved", headers=admin
    ).json()["items"]
    mapping = next(m for m in unresolved if m["external_identifier"] == "acc-ext-9f21")

    resp = client.patch(
        f"/api/v1/integrations/identity-mappings/{mapping['id']}/resolve",
        json={"employee_id": contractor_employee["id"]},
        headers=admin,
    )
    assert resp.status_code == 200
    assert resp.json()["status"] == "resolved"
    assert resp.json()["employee_id"] == contractor_employee["id"]


def test_non_admin_cannot_resolve_identity_mapping(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.patch(
        "/api/v1/integrations/identity-mappings/00000000-0000-0000-0000-000000000000/resolve",
        json={"employee_id": "00000000-0000-0000-0000-000000000000"},
        headers=headers,
    )
    assert resp.status_code == 403


def test_resolving_nonexistent_mapping_returns_404(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    employee = _seed_employee(client, admin)
    resp = client.patch(
        "/api/v1/integrations/identity-mappings/00000000-0000-0000-0000-000000000000/resolve",
        json={"employee_id": employee["id"]},
        headers=admin,
    )
    assert resp.status_code == 404


def test_jira_sync_creates_audit_log_entry(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    _seed_projects(client, admin)
    _seed_employee(client, admin)

    client.post("/api/v1/integrations/jira/sync", headers=admin)

    logs = client.get("/api/v1/audit-logs?action=integration.sync", headers=admin).json()
    assert logs["total"] >= 1
