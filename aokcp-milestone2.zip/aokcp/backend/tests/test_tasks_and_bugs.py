def _create_project(client, admin_headers):
    return client.post(
        "/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin_headers
    ).json()


def test_manager_can_create_task(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    manager, _ = make_auth_headers("manager")
    project = _create_project(client, admin)

    resp = client.post(
        "/api/v1/tasks",
        json={"project_id": project["id"], "title": "Fix retry bug", "type": "task"},
        headers=manager,
    )
    assert resp.status_code == 201
    assert resp.json()["status"] == "open"
    assert resp.json()["type"] == "task"


def test_employee_cannot_create_task(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    employee, _ = make_auth_headers("employee")
    project = _create_project(client, admin)

    resp = client.post(
        "/api/v1/tasks", json={"project_id": project["id"], "title": "X"}, headers=employee
    )
    assert resp.status_code == 403


def test_creating_bug_type_task_also_creates_bug_row(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    project = _create_project(client, admin)

    resp = client.post(
        "/api/v1/tasks",
        json={"project_id": project["id"], "title": "Duplicate charge", "type": "bug", "severity": "high"},
        headers=admin,
    )
    assert resp.status_code == 201
    task_id = resp.json()["id"]

    bugs = client.get(f"/api/v1/bugs?project_id={project['id']}", headers=admin).json()
    assert bugs["total"] == 1
    assert bugs["items"][0]["task_id"] == task_id
    assert bugs["items"][0]["severity"] == "high"


def test_tasks_list_excludes_bugs(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    project = _create_project(client, admin)
    client.post("/api/v1/tasks", json={"project_id": project["id"], "title": "A task"}, headers=admin)
    client.post(
        "/api/v1/tasks", json={"project_id": project["id"], "title": "A bug", "type": "bug"}, headers=admin
    )

    tasks = client.get(f"/api/v1/tasks?project_id={project['id']}", headers=admin).json()
    assert tasks["total"] == 1
    assert tasks["items"][0]["title"] == "A task"


def test_any_authenticated_user_can_update_task_status(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    employee, _ = make_auth_headers("employee")
    project = _create_project(client, admin)
    task = client.post(
        "/api/v1/tasks", json={"project_id": project["id"], "title": "A task"}, headers=admin
    ).json()

    resp = client.patch(f"/api/v1/tasks/{task['id']}", json={"status": "in_progress"}, headers=employee)
    assert resp.status_code == 200
    assert resp.json()["status"] == "in_progress"


def test_filter_bugs_by_severity(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    project = _create_project(client, admin)
    client.post(
        "/api/v1/tasks",
        json={"project_id": project["id"], "title": "Critical bug", "type": "bug", "severity": "critical"},
        headers=admin,
    )
    client.post(
        "/api/v1/tasks",
        json={"project_id": project["id"], "title": "Minor bug", "type": "bug", "severity": "low"},
        headers=admin,
    )

    resp = client.get("/api/v1/bugs?severity=critical", headers=admin)
    body = resp.json()
    assert body["total"] == 1
    assert body["items"][0]["severity"] == "critical"
