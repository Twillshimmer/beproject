import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401 ensure models are registered
from app.db.session import Base, get_db
from app.main import app
from app.models.role import Role


@pytest.fixture()
def db_session():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)

    session = TestingSessionLocal()
    try:
        # Seed the roles a fresh test DB needs, mirroring app/seed.py.
        for name in ("admin", "manager", "employee"):
            session.add(Role(name=name, description=f"{name} role"))
        session.commit()
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture()
def make_auth_headers(db_session):
    """Factory fixture: create a user with a given role directly in the test
    DB and return Authorization headers for them. Used across M2+ tests to
    exercise RBAC without re-implementing registration each time."""
    from app.auth.jwt import create_access_token
    from app.auth.security import hash_password
    from app.models.role import Role
    from app.models.user import User

    def _make(role_name: str = "employee", email: str | None = None):
        role = db_session.query(Role).filter(Role.name == role_name).one()
        email = email or f"{role_name}@example.com"
        user = User(
            email=email,
            hashed_password=hash_password("SecurePass123"),
            full_name=f"{role_name.capitalize()} User",
            role=role,
        )
        db_session.add(user)
        db_session.commit()
        db_session.refresh(user)
        token = create_access_token(subject=str(user.id), extra_claims={"role": role.name})
        return {"Authorization": f"Bearer {token}"}, user

    return _make
