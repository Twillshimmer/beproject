def _create_department(client, admin_headers, name="Engineering"):
    return client.post("/api/v1/departments", json={"name": name}, headers=admin_headers).json()


def test_admin_can_create_employee(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    dept = _create_department(client, admin)
    resp = client.post(
        "/api/v1/employees",
        json={"full_name": "Jane Doe", "email": "jane@corp.com", "department_id": dept["id"]},
        headers=admin,
    )
    assert resp.status_code == 201
    assert resp.json()["email"] == "jane@corp.com"
    assert resp.json()["status"] == "active"


def test_employee_cannot_create_employee(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post(
        "/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=headers
    )
    assert resp.status_code == 403


def test_duplicate_employee_email_rejected(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    payload = {"full_name": "Jane Doe", "email": "jane@corp.com"}
    client.post("/api/v1/employees", json=payload, headers=admin)
    resp = client.post("/api/v1/employees", json=payload, headers=admin)
    assert resp.status_code == 400


def test_search_employees_by_name(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    client.post("/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=admin)
    client.post("/api/v1/employees", json={"full_name": "Bob Smith", "email": "bob@corp.com"}, headers=admin)

    resp = client.get("/api/v1/employees?q=Jane", headers=admin)
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 1
    assert body["items"][0]["full_name"] == "Jane Doe"


def test_filter_employees_by_department(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    eng = _create_department(client, admin, "Engineering")
    sales = _create_department(client, admin, "Sales")
    client.post(
        "/api/v1/employees",
        json={"full_name": "Jane Doe", "email": "jane@corp.com", "department_id": eng["id"]},
        headers=admin,
    )
    client.post(
        "/api/v1/employees",
        json={"full_name": "Bob Smith", "email": "bob@corp.com", "department_id": sales["id"]},
        headers=admin,
    )

    resp = client.get(f"/api/v1/employees?department_id={eng['id']}", headers=admin)
    body = resp.json()
    assert body["total"] == 1
    assert body["items"][0]["full_name"] == "Jane Doe"


def test_employee_pagination(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    for i in range(5):
        client.post(
            "/api/v1/employees",
            json={"full_name": f"Person {i}", "email": f"person{i}@corp.com"},
            headers=admin,
        )
    resp = client.get("/api/v1/employees?page=1&page_size=2", headers=admin)
    body = resp.json()
    assert body["total"] == 5
    assert len(body["items"]) == 2


def test_manager_can_update_employee_but_not_create(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    manager, _ = make_auth_headers("manager")
    emp = client.post(
        "/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=admin
    ).json()

    resp = client.patch(f"/api/v1/employees/{emp['id']}", json={"title": "Senior Engineer"}, headers=manager)
    assert resp.status_code == 200
    assert resp.json()["title"] == "Senior Engineer"

    resp = client.post(
        "/api/v1/employees", json={"full_name": "X", "email": "x@corp.com"}, headers=manager
    )
    assert resp.status_code == 403


def test_get_nonexistent_employee_returns_404(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.get("/api/v1/employees/00000000-0000-0000-0000-000000000000", headers=headers)
    assert resp.status_code == 404


def test_employee_projects_endpoint_reflects_memberships(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    employee = client.post(
        "/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=admin
    ).json()
    project = client.post(
        "/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin
    ).json()

    resp = client.get(f"/api/v1/employees/{employee['id']}/projects", headers=admin)
    assert resp.status_code == 200
    assert resp.json() == []

    client.post(
        f"/api/v1/projects/{project['id']}/members",
        json={"employee_id": employee["id"], "role_on_project": "Tech Lead"},
        headers=admin,
    )
    resp = client.get(f"/api/v1/employees/{employee['id']}/projects", headers=admin)
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["project"]["key"] == "PAY"
    assert body[0]["role_on_project"] == "Tech Lead"


def test_employee_projects_endpoint_404s_for_unknown_employee(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.get(
        "/api/v1/employees/00000000-0000-0000-0000-000000000000/projects", headers=headers
    )
    assert resp.status_code == 404
