def test_admin_can_create_department(client, make_auth_headers):
    headers, _ = make_auth_headers("admin")
    resp = client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers)
    assert resp.status_code == 201
    assert resp.json()["name"] == "Engineering"


def test_employee_cannot_create_department(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers)
    assert resp.status_code == 403


def test_duplicate_department_name_rejected(client, make_auth_headers):
    headers, _ = make_auth_headers("admin")
    client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers)
    resp = client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers)
    assert resp.status_code == 400


def test_any_authenticated_user_can_list_departments(client, make_auth_headers):
    admin_headers, _ = make_auth_headers("admin")
    client.post("/api/v1/departments", json={"name": "Engineering"}, headers=admin_headers)

    emp_headers, _ = make_auth_headers("employee")
    resp = client.get("/api/v1/departments", headers=emp_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_list_departments_requires_authentication(client):
    resp = client.get("/api/v1/departments")
    assert resp.status_code == 401


def test_get_nonexistent_department_returns_404(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.get("/api/v1/departments/00000000-0000-0000-0000-000000000000", headers=headers)
    assert resp.status_code == 404


def test_admin_can_update_department(client, make_auth_headers):
    headers, _ = make_auth_headers("admin")
    dept = client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers).json()
    resp = client.patch(
        f"/api/v1/departments/{dept['id']}", json={"description": "Builds the platform"}, headers=headers
    )
    assert resp.status_code == 200
    assert resp.json()["description"] == "Builds the platform"


def test_admin_can_delete_department(client, make_auth_headers):
    headers, _ = make_auth_headers("admin")
    dept = client.post("/api/v1/departments", json={"name": "Engineering"}, headers=headers).json()
    resp = client.delete(f"/api/v1/departments/{dept['id']}", headers=headers)
    assert resp.status_code == 204
    assert client.get(f"/api/v1/departments/{dept['id']}", headers=headers).status_code == 404
