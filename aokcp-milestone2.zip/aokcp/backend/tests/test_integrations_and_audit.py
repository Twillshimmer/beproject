def test_admin_sees_all_integration_types_with_mock_mode_by_default(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    resp = client.get("/api/v1/integrations", headers=admin)
    assert resp.status_code == 200
    types = {row["type"]: row["mode"] for row in resp.json()}
    assert types == {"jira": "mock", "github": "mock", "hr": "mock", "documents": "mock"}


def test_non_admin_cannot_view_integrations(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.get("/api/v1/integrations", headers=headers)
    assert resp.status_code == 403


def test_admin_can_disable_an_integration(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    resp = client.patch("/api/v1/integrations/jira", json={"is_enabled": False}, headers=admin)
    assert resp.status_code == 200
    assert resp.json()["is_enabled"] is False


def test_sync_logs_empty_list_before_any_sync(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    resp = client.get("/api/v1/integrations/jira/sync-logs", headers=admin)
    assert resp.status_code == 200
    assert resp.json() == []


def test_non_admin_cannot_view_audit_logs(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.get("/api/v1/audit-logs", headers=headers)
    assert resp.status_code == 403


def test_admin_sees_audit_log_entries_after_a_write_action(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    client.post("/api/v1/departments", json={"name": "Engineering"}, headers=admin)

    resp = client.get("/api/v1/audit-logs", headers=admin)
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] >= 1
    actions = [item["action"] for item in body["items"]]
    assert "department.create" in actions


def test_dashboard_stats_reflect_real_data(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    client.post("/api/v1/departments", json={"name": "Engineering"}, headers=admin)
    client.post("/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=admin)
    client.post("/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin)

    resp = client.get("/api/v1/dashboard/stats", headers=admin)
    assert resp.status_code == 200
    body = resp.json()
    assert body["total_employees"] == 1
    assert body["total_projects"] == 1
    assert body["active_projects"] == 1
