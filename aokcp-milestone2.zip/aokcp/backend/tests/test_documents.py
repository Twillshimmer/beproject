import io


def test_upload_valid_document(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post(
        "/api/v1/documents",
        files={"file": ("architecture.md", io.BytesIO(b"# Architecture\nSome notes."), "text/markdown")},
        data={"title": "Architecture Notes"},
        headers=headers,
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["file_type"] == "md"
    assert body["status"] == "uploaded"
    assert body["title"] == "Architecture Notes"


def test_upload_rejects_disallowed_extension(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post(
        "/api/v1/documents",
        files={"file": ("script.exe", io.BytesIO(b"binary"), "application/octet-stream")},
        headers=headers,
    )
    assert resp.status_code == 400
    assert "Unsupported file type" in resp.json()["detail"]


def test_upload_requires_authentication(client):
    resp = client.post(
        "/api/v1/documents",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
    )
    assert resp.status_code == 401


def test_list_and_get_and_delete_document(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    upload = client.post(
        "/api/v1/documents",
        files={"file": ("notes.txt", io.BytesIO(b"hello world"), "text/plain")},
        headers=headers,
    ).json()

    listed = client.get("/api/v1/documents", headers=headers).json()
    assert listed["total"] == 1

    got = client.get(f"/api/v1/documents/{upload['id']}", headers=headers)
    assert got.status_code == 200

    deleted = client.delete(f"/api/v1/documents/{upload['id']}", headers=headers)
    assert deleted.status_code == 204
    assert client.get(f"/api/v1/documents/{upload['id']}", headers=headers).status_code == 404
