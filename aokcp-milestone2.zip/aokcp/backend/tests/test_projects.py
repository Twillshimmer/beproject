def test_admin_can_create_project(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    resp = client.post(
        "/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin
    )
    assert resp.status_code == 201
    assert resp.json()["key"] == "PAY"
    assert resp.json()["status"] == "active"


def test_employee_cannot_create_project(client, make_auth_headers):
    headers, _ = make_auth_headers("employee")
    resp = client.post("/api/v1/projects", json={"name": "X", "key": "X"}, headers=headers)
    assert resp.status_code == 403


def test_duplicate_project_key_rejected(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    client.post("/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin)
    resp = client.post("/api/v1/projects", json={"name": "Payments 2", "key": "PAY"}, headers=admin)
    assert resp.status_code == 400


def test_search_and_filter_projects(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    client.post("/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin)
    client.post("/api/v1/projects", json={"name": "Notification Service", "key": "NOTIF"}, headers=admin)

    resp = client.get("/api/v1/projects?q=Payment", headers=admin)
    body = resp.json()
    assert body["total"] == 1
    assert body["items"][0]["key"] == "PAY"


def test_add_and_list_and_remove_project_member(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    project = client.post(
        "/api/v1/projects", json={"name": "Payment Platform", "key": "PAY"}, headers=admin
    ).json()
    employee = client.post(
        "/api/v1/employees", json={"full_name": "Jane Doe", "email": "jane@corp.com"}, headers=admin
    ).json()

    resp = client.post(
        f"/api/v1/projects/{project['id']}/members",
        json={"employee_id": employee["id"], "role_on_project": "Tech Lead"},
        headers=admin,
    )
    assert resp.status_code == 201
    assert resp.json()["employee"]["full_name"] == "Jane Doe"

    resp = client.get(f"/api/v1/projects/{project['id']}/members", headers=admin)
    assert len(resp.json()) == 1

    resp = client.post(
        f"/api/v1/projects/{project['id']}/members",
        json={"employee_id": employee["id"]},
        headers=admin,
    )
    assert resp.status_code == 400  # already a member

    resp = client.delete(f"/api/v1/projects/{project['id']}/members/{employee['id']}", headers=admin)
    assert resp.status_code == 204
    assert client.get(f"/api/v1/projects/{project['id']}/members", headers=admin).json() == []


def test_project_pagination(client, make_auth_headers):
    admin, _ = make_auth_headers("admin")
    for i in range(3):
        client.post("/api/v1/projects", json={"name": f"Project {i}", "key": f"P{i}"}, headers=admin)
    resp = client.get("/api/v1/projects?page=1&page_size=2", headers=admin)
    body = resp.json()
    assert body["total"] == 3
    assert len(body["items"]) == 2
