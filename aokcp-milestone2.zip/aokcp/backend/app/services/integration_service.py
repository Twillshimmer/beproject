from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.integration_config import IntegrationConfig
from app.models.user import User
from app.repositories.integration_repository import IntegrationConfigRepository
from app.repositories.sync_log_repository import SyncLogRepository
from app.services.audit_service import AuditService

settings = get_settings()

# Every integration type this platform supports, and whether live credentials
# are currently configured (drives the mock/live mode shown to the admin).
INTEGRATION_TYPES = ["jira", "github", "hr", "documents"]


class IntegrationService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = IntegrationConfigRepository(db)
        self.sync_log_repo = SyncLogRepository(db)
        self.audit = AuditService(db)

    def _live_mode_available(self, integration_type: str) -> bool:
        if integration_type == "jira":
            return settings.jira_configured
        if integration_type == "github":
            return settings.github_configured
        # HR and Documents integrations don't have external credentials in
        # this build — they are always effectively "mock"/manual.
        return False

    def list_integrations(self) -> list[IntegrationConfig]:
        """Ensures a row exists for every known integration type (created on
        first read with the mode inferred from whether credentials are set),
        then returns them all — so the UI always has something to render."""
        existing = {c.type: c for c in self.repo.list_all()}
        for integration_type in INTEGRATION_TYPES:
            if integration_type not in existing:
                mode = "live" if self._live_mode_available(integration_type) else "mock"
                existing[integration_type] = self.repo.upsert(
                    type=integration_type, mode=mode, config={}
                )
        return [existing[t] for t in INTEGRATION_TYPES]

    def get_integration(self, integration_type: str) -> IntegrationConfig | None:
        return self.repo.get_by_type(integration_type)

    def update_integration(
        self, *, actor: User, integration_type: str, is_enabled: bool | None, config: dict | None
    ) -> IntegrationConfig:
        entry = self.repo.get_by_type(integration_type)
        if entry is None:
            mode = "live" if self._live_mode_available(integration_type) else "mock"
            entry = self.repo.upsert(type=integration_type, mode=mode, config=config or {})
        entry = self.repo.update(entry, is_enabled=is_enabled, config=config)
        self.audit.log(
            user_id=actor.id, action="integration.update", resource_type="integration_config",
            resource_id=integration_type, metadata={"is_enabled": is_enabled},
        )
        return entry

    def list_sync_logs(self, *, integration_type: str | None = None, offset=0, limit=20):
        return self.sync_log_repo.search(integration_type=integration_type, offset=offset, limit=limit)
