import os
import uuid

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.document import Document
from app.models.user import User
from app.repositories.document_repository import DocumentRepository
from app.services.audit_service import AuditService

settings = get_settings()

ALLOWED_EXTENSIONS = {"pdf", "docx", "txt", "md"}


class DocumentError(Exception):
    pass


class DocumentNotFoundError(DocumentError):
    pass


class DocumentValidationError(DocumentError):
    pass


class DocumentService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = DocumentRepository(db)
        self.audit = AuditService(db)

    def search_documents(self, **kwargs) -> tuple[list[Document], int]:
        return self.repo.search(**kwargs)

    def get_document(self, document_id: uuid.UUID) -> Document:
        document = self.repo.get(document_id)
        if document is None:
            raise DocumentNotFoundError("Document not found")
        return document

    def validate_upload(self, *, filename: str, size_bytes: int) -> str:
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in ALLOWED_EXTENSIONS:
            raise DocumentValidationError(
                f"Unsupported file type '.{ext}'. Allowed types: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
            )
        if size_bytes > settings.MAX_UPLOAD_SIZE:
            max_mb = settings.MAX_UPLOAD_SIZE / (1024 * 1024)
            raise DocumentValidationError(f"File exceeds the {max_mb:.0f} MB upload limit")
        return ext

    def store_upload(
        self, *, actor: User, filename: str, file_type: str, content: bytes,
        title: str | None, project_id: uuid.UUID | None, department_id: uuid.UUID | None,
    ) -> Document:
        os.makedirs(settings.UPLOAD_DIRECTORY, exist_ok=True)
        # A random-prefixed, extension-preserved filename — never trust the
        # client's raw filename as a filesystem path, and never execute it.
        stored_name = f"{uuid.uuid4()}.{file_type}"
        stored_path = os.path.join(settings.UPLOAD_DIRECTORY, stored_name)
        with open(stored_path, "wb") as f:
            f.write(content)

        document = self.repo.create(
            title=title or filename,
            filename=filename,
            file_path=stored_path,
            file_type=file_type,
            size_bytes=len(content),
            # Honest status: no extraction/chunking/embedding pipeline exists
            # yet (that lands in Milestones 5 & 7), so this is not
            # "processing" or "processed" — it is simply stored.
            status="uploaded",
            uploaded_by=actor.id,
            project_id=project_id,
            department_id=department_id,
        )
        self.audit.log(
            user_id=actor.id, action="document.upload", resource_type="document",
            resource_id=str(document.id), metadata={"filename": filename, "file_type": file_type},
        )
        return document

    def delete_document(self, *, actor: User, document_id: uuid.UUID) -> None:
        document = self.get_document(document_id)
        if os.path.exists(document.file_path):
            os.remove(document.file_path)
        self.repo.delete(document)
        self.audit.log(
            user_id=actor.id, action="document.delete", resource_type="document",
            resource_id=str(document_id),
        )
