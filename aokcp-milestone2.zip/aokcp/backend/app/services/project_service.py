import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.models.project import Project
from app.models.project_member import ProjectMember
from app.models.user import User
from app.repositories.project_member_repository import ProjectMemberRepository
from app.repositories.project_repository import ProjectRepository
from app.services.audit_service import AuditService


class ProjectError(Exception):
    pass


class ProjectNotFoundError(ProjectError):
    pass


class ProjectService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = ProjectRepository(db)
        self.member_repo = ProjectMemberRepository(db)
        self.audit = AuditService(db)

    def search_projects(
        self, *, query=None, department_id=None, status_filter=None, offset=0, limit=20
    ) -> tuple[list[Project], int]:
        return self.repo.search(
            query=query,
            department_id=department_id,
            status_filter=status_filter,
            offset=offset,
            limit=limit,
        )

    def get_project(self, project_id: uuid.UUID) -> Project:
        project = self.repo.get(project_id)
        if project is None:
            raise ProjectNotFoundError("Project not found")
        return project

    def create_project(self, *, actor: User, **fields) -> Project:
        if self.repo.get_by_key(fields["key"]):
            raise ProjectError("A project with this key already exists")
        project = self.repo.create(**fields)
        self.audit.log(
            user_id=actor.id, action="project.create", resource_type="project",
            resource_id=str(project.id), metadata={"key": project.key},
        )
        return project

    def update_project(self, *, actor: User, project_id: uuid.UUID, **fields) -> Project:
        project = self.get_project(project_id)
        project = self.repo.update(project, **fields)
        self.audit.log(
            user_id=actor.id, action="project.update", resource_type="project",
            resource_id=str(project.id),
            metadata={k: str(v) for k, v in fields.items() if v is not None},
        )
        return project

    def list_members(self, project_id: uuid.UUID) -> list[ProjectMember]:
        self.get_project(project_id)  # 404 if missing
        return self.member_repo.list_for_project(project_id)

    def add_member(
        self, *, actor: User, project_id: uuid.UUID, employee_id: uuid.UUID,
        role_on_project: str | None, joined_at: date | None,
    ) -> ProjectMember:
        self.get_project(project_id)
        if self.member_repo.get(project_id, employee_id):
            raise ProjectError("This employee is already a member of the project")
        member = self.member_repo.add(
            project_id=project_id, employee_id=employee_id,
            role_on_project=role_on_project, joined_at=joined_at,
        )
        self.audit.log(
            user_id=actor.id, action="project.add_member", resource_type="project",
            resource_id=str(project_id), metadata={"employee_id": str(employee_id)},
        )
        return member

    def remove_member(self, *, actor: User, project_id: uuid.UUID, employee_id: uuid.UUID) -> None:
        member = self.member_repo.get(project_id, employee_id)
        if member is None:
            raise ProjectError("This employee is not a member of the project")
        self.member_repo.remove(member)
        self.audit.log(
            user_id=actor.id, action="project.remove_member", resource_type="project",
            resource_id=str(project_id), metadata={"employee_id": str(employee_id)},
        )
