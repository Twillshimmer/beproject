import uuid

from sqlalchemy.orm import Session

from app.models.department import Department
from app.models.user import User
from app.repositories.department_repository import DepartmentRepository
from app.services.audit_service import AuditService


class DepartmentError(Exception):
    pass


class DepartmentNotFoundError(DepartmentError):
    pass


class DepartmentService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = DepartmentRepository(db)
        self.audit = AuditService(db)

    def list_departments(self) -> list[Department]:
        return self.repo.list_all()

    def get_department(self, department_id: uuid.UUID) -> Department:
        dept = self.repo.get(department_id)
        if dept is None:
            raise DepartmentNotFoundError("Department not found")
        return dept

    def create_department(self, *, actor: User, name: str, description: str | None,
                           manager_employee_id: uuid.UUID | None) -> Department:
        if self.repo.get_by_name(name):
            raise DepartmentError("A department with this name already exists")
        dept = self.repo.create(
            name=name, description=description, manager_employee_id=manager_employee_id
        )
        self.audit.log(
            user_id=actor.id, action="department.create", resource_type="department",
            resource_id=str(dept.id), metadata={"name": name},
        )
        return dept

    def update_department(self, *, actor: User, department_id: uuid.UUID, **fields) -> Department:
        dept = self.get_department(department_id)
        dept = self.repo.update(dept, **fields)
        self.audit.log(
            user_id=actor.id, action="department.update", resource_type="department",
            resource_id=str(dept.id), metadata={k: str(v) for k, v in fields.items() if v is not None},
        )
        return dept

    def delete_department(self, *, actor: User, department_id: uuid.UUID) -> None:
        dept = self.get_department(department_id)
        self.repo.delete(dept)
        self.audit.log(
            user_id=actor.id, action="department.delete", resource_type="department",
            resource_id=str(department_id),
        )
