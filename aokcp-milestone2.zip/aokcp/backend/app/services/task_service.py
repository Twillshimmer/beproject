import uuid

from sqlalchemy.orm import Session

from app.models.bug import Bug
from app.models.task import Task
from app.models.user import User
from app.repositories.task_repository import BugRepository, TaskRepository
from app.services.audit_service import AuditService


class TaskError(Exception):
    pass


class TaskNotFoundError(TaskError):
    pass


class TaskService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = TaskRepository(db)
        self.bug_repo = BugRepository(db)
        self.audit = AuditService(db)

    def search_tasks(self, **kwargs) -> tuple[list[Task], int]:
        return self.repo.search(**kwargs)

    def search_bugs(self, **kwargs) -> tuple[list[Bug], int]:
        return self.bug_repo.search(**kwargs)

    def get_task(self, task_id: uuid.UUID) -> Task:
        task = self.repo.get(task_id)
        if task is None:
            raise TaskNotFoundError("Task not found")
        return task

    def create_task(
        self, *, actor: User, project_id: uuid.UUID, title: str, description: str | None,
        priority: str, type: str, assignee_id: uuid.UUID | None, severity: str | None = None,
    ) -> Task:
        task = self.repo.create(
            project_id=project_id, title=title, description=description, priority=priority,
            type=type, assignee_id=assignee_id, source="manual",
        )
        if type == "bug":
            self.bug_repo.create(task_id=task.id, severity=severity or "medium")
            self.db.refresh(task)
        self.audit.log(
            user_id=actor.id, action="task.create", resource_type="task",
            resource_id=str(task.id), metadata={"project_id": str(project_id), "type": type},
        )
        return task

    def update_task(self, *, actor: User, task_id: uuid.UUID, **fields) -> Task:
        task = self.get_task(task_id)
        task = self.repo.update(task, **fields)
        self.audit.log(
            user_id=actor.id, action="task.update", resource_type="task",
            resource_id=str(task.id),
            metadata={k: str(v) for k, v in fields.items() if v is not None},
        )
        return task
