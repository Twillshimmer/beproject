import uuid

from sqlalchemy.orm import Session

from app.models.employee import Employee
from app.models.user import User
from app.repositories.employee_repository import EmployeeRepository
from app.services.audit_service import AuditService


class EmployeeError(Exception):
    pass


class EmployeeNotFoundError(EmployeeError):
    pass


class EmployeeService:
    def __init__(self, db: Session):
        self.db = db
        self.repo = EmployeeRepository(db)
        self.audit = AuditService(db)

    def search_employees(
        self,
        *,
        query: str | None = None,
        department_id: uuid.UUID | None = None,
        project_id: uuid.UUID | None = None,
        status_filter: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Employee], int]:
        return self.repo.search(
            query=query,
            department_id=department_id,
            project_id=project_id,
            status_filter=status_filter,
            offset=offset,
            limit=limit,
        )

    def get_employee(self, employee_id: uuid.UUID) -> Employee:
        employee = self.repo.get(employee_id)
        if employee is None:
            raise EmployeeNotFoundError("Employee not found")
        return employee

    def create_employee(self, *, actor: User, **fields) -> Employee:
        if self.repo.get_by_email(fields["email"]):
            raise EmployeeError("An employee with this email already exists")
        employee = self.repo.create(**fields)
        self.audit.log(
            user_id=actor.id, action="employee.create", resource_type="employee",
            resource_id=str(employee.id), metadata={"email": employee.email},
        )
        return employee

    def update_employee(self, *, actor: User, employee_id: uuid.UUID, **fields) -> Employee:
        employee = self.get_employee(employee_id)
        employee = self.repo.update(employee, **fields)
        self.audit.log(
            user_id=actor.id, action="employee.update", resource_type="employee",
            resource_id=str(employee.id),
            metadata={k: str(v) for k, v in fields.items() if v is not None},
        )
        return employee

    def mark_departed(self, *, actor: User, employee_id: uuid.UUID, left_date) -> Employee:
        """Marks an employee as having left — the trigger point for handover
        generation in Milestone 10."""
        employee = self.update_employee(
            actor=actor, employee_id=employee_id, status="left", left_date=left_date
        )
        self.audit.log(
            user_id=actor.id, action="employee.mark_departed", resource_type="employee",
            resource_id=str(employee.id),
        )
        return employee
