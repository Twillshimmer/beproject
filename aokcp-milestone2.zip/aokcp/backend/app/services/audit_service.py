import uuid

from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


class AuditService:
    """Central place that writes AuditLog rows. Never stores credentials or
    other secrets in `log_metadata` — only IDs, names, and outcome status."""

    def __init__(self, db: Session):
        self.db = db

    def log(
        self,
        *,
        user_id: uuid.UUID | None,
        action: str,
        resource_type: str,
        resource_id: str | None = None,
        metadata: dict | None = None,
        status: str = "success",
    ) -> AuditLog:
        entry = AuditLog(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            log_metadata=metadata or {},
            status=status,
        )
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry
