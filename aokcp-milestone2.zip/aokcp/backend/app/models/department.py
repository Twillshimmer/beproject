import uuid

from sqlalchemy import String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import TimestampedModel


class Department(TimestampedModel):
    __tablename__ = "departments"

    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # No ForeignKey object here on purpose: departments <-> employees is a
    # circular reference (a department has a manager employee; an employee
    # belongs to a department). The referential constraint is still created
    # in the Postgres migration (see 0002, op.create_foreign_key), but
    # declaring it on the ORM column too would force SQLAlchemy to emit a
    # deferred ALTER TABLE ADD CONSTRAINT on create_all() — which SQLite
    # (used by the test suite) does not support. Keeping this a plain column
    # avoids that footgun while production integrity is still enforced.
    manager_employee_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )

    employees: Mapped[list["Employee"]] = relationship(
        back_populates="department", foreign_keys="Employee.department_id"
    )
    projects: Mapped[list["Project"]] = relationship(back_populates="department")
