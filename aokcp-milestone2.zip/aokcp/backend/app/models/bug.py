import uuid

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import TimestampedModel


class Bug(TimestampedModel):
    """1:1 extension of Task carrying bug-specific fields. A Task with
    type='bug' should always have a corresponding Bug row (enforced in the
    service layer, not the DB, to keep the migration simple)."""

    __tablename__ = "bugs"

    task_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tasks.id"), unique=True, nullable=False, index=True
    )
    severity: Mapped[str] = mapped_column(String(20), default="medium", nullable=False, index=True)
    resolution: Mapped[str | None] = mapped_column(Text, nullable=True)

    task: Mapped["Task"] = relationship(back_populates="bug")
