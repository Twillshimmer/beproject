from datetime import datetime

from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import TimestampedModel


class IntegrationConfig(TimestampedModel):
    """Stores non-secret integration settings (base URLs, feature flags).
    Actual credentials (API tokens) are read from environment variables only
    — never persisted here — per IMPLEMENTATION_PLAN.md §13."""

    __tablename__ = "integration_configs"

    type: Mapped[str] = mapped_column(
        String(20), unique=True, nullable=False, index=True
    )  # jira | github | hr | documents
    mode: Mapped[str] = mapped_column(String(10), default="mock", nullable=False)  # live | mock
    config: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
