import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import TimestampedModel


class Task(TimestampedModel):
    """Represents a Jira-style work item. `type` distinguishes task/story/bug.
    Bug-specific fields (severity, resolution) live in the related `Bug` row
    (see app/models/bug.py) rather than duplicating this whole table, per the
    documented assumption in IMPLEMENTATION_PLAN.md §13."""

    __tablename__ = "tasks"
    __table_args__ = (
        UniqueConstraint("source", "external_id", name="uq_task_source_external_id"),
    )

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False, index=True
    )
    external_id: Mapped[str | None] = mapped_column(String(50), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="open", nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    type: Mapped[str] = mapped_column(String(20), default="task", nullable=False, index=True)
    source: Mapped[str] = mapped_column(String(20), default="manual", nullable=False)  # jira|manual

    assignee_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("employees.id"), nullable=True, index=True
    )
    assignee: Mapped["Employee | None"] = relationship()

    created_at_source: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at_source: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    project: Mapped["Project"] = relationship(back_populates="tasks")
    bug: Mapped["Bug | None"] = relationship(back_populates="task", uselist=False)
