import uuid

from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import TimestampedModel


class IdentityMapping(TimestampedModel):
    """Maps an external-system identity (Jira account, GitHub username,
    commit author email) to an Employee. Created by M3/M4 sync services;
    the table is defined now alongside the rest of the core schema."""

    __tablename__ = "identity_mappings"
    __table_args__ = (
        UniqueConstraint(
            "external_system", "external_identifier", name="uq_identity_mapping"
        ),
    )

    external_system: Mapped[str] = mapped_column(String(20), nullable=False, index=True)  # jira|github
    external_identifier: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    employee_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("employees.id"), nullable=True, index=True
    )
    status: Mapped[str] = mapped_column(
        String(20), default="unresolved", nullable=False, index=True
    )  # resolved|unresolved
    resolved_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )

    employee: Mapped["Employee | None"] = relationship()
