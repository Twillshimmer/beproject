"""Import every model here so Alembic's autogenerate and Base.metadata see
the full schema. Add new model modules as milestones introduce them."""
from app.models.role import Role  # noqa: F401
from app.models.department import Department  # noqa: F401
from app.models.employee import Employee  # noqa: F401
from app.models.user import User  # noqa: F401
from app.models.project import Project  # noqa: F401
from app.models.project_member import ProjectMember  # noqa: F401
from app.models.task import Task  # noqa: F401
from app.models.bug import Bug  # noqa: F401
from app.models.document import Document  # noqa: F401
from app.models.integration_config import IntegrationConfig  # noqa: F401
from app.models.sync_log import SyncLog  # noqa: F401
from app.models.audit_log import AuditLog  # noqa: F401
from app.models.identity_mapping import IdentityMapping  # noqa: F401
