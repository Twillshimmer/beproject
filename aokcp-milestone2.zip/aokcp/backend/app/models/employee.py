import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import TimestampedModel


class Employee(TimestampedModel):
    __tablename__ = "employees"

    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active", nullable=False, index=True)
    hire_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    left_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # Identity-linking fields used by Jira/GitHub sync in later milestones.
    github_username: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    jira_account_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)

    department_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("departments.id"), nullable=True, index=True
    )
    department: Mapped["Department | None"] = relationship(
        back_populates="employees", foreign_keys=[department_id]
    )

    manager_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("employees.id"), nullable=True, index=True
    )
    manager: Mapped["Employee | None"] = relationship(
        remote_side="Employee.id", foreign_keys=[manager_id]
    )

    project_memberships: Mapped[list["ProjectMember"]] = relationship(back_populates="employee")
