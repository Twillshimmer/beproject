import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.department import Department


class DepartmentRepository:
    def __init__(self, db: Session):
        self.db = db

    def list_all(self) -> list[Department]:
        return list(self.db.execute(select(Department).order_by(Department.name)).scalars())

    def get(self, department_id: uuid.UUID) -> Department | None:
        return self.db.get(Department, department_id)

    def get_by_name(self, name: str) -> Department | None:
        stmt = select(Department).where(Department.name == name)
        return self.db.execute(stmt).scalar_one_or_none()

    def create(self, **fields) -> Department:
        dept = Department(**fields)
        self.db.add(dept)
        self.db.commit()
        self.db.refresh(dept)
        return dept

    def update(self, dept: Department, **fields) -> Department:
        for key, value in fields.items():
            if value is not None:
                setattr(dept, key, value)
        self.db.commit()
        self.db.refresh(dept)
        return dept

    def delete(self, dept: Department) -> None:
        self.db.delete(dept)
        self.db.commit()
