import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from app.models.bug import Bug
from app.models.task import Task


class TaskRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(
        self, *, project_id=None, assignee_id=None, status_filter=None, type_filter=None,
        offset=0, limit=20,
    ) -> tuple[list[Task], int]:
        stmt = select(Task)
        if project_id is not None:
            stmt = stmt.where(Task.project_id == project_id)
        if assignee_id is not None:
            stmt = stmt.where(Task.assignee_id == assignee_id)
        if status_filter:
            stmt = stmt.where(Task.status == status_filter)
        if type_filter:
            stmt = stmt.where(Task.type == type_filter)

        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(Task.created_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def get(self, task_id: uuid.UUID) -> Task | None:
        return self.db.get(Task, task_id)

    def create(self, **fields) -> Task:
        task = Task(**fields)
        self.db.add(task)
        self.db.commit()
        self.db.refresh(task)
        return task

    def update(self, task: Task, **fields) -> Task:
        for key, value in fields.items():
            if value is not None:
                setattr(task, key, value)
        self.db.commit()
        self.db.refresh(task)
        return task


class BugRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(self, *, project_id=None, severity=None, offset=0, limit=20) -> tuple[list[Bug], int]:
        stmt = select(Bug).join(Task, Bug.task_id == Task.id).options(joinedload(Bug.task))
        if project_id is not None:
            stmt = stmt.where(Task.project_id == project_id)
        if severity:
            stmt = stmt.where(Bug.severity == severity)

        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(Bug.created_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def create(self, **fields) -> Bug:
        bug = Bug(**fields)
        self.db.add(bug)
        self.db.commit()
        self.db.refresh(bug)
        return bug
