from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.sync_log import SyncLog


class SyncLogRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(self, *, integration_type=None, offset=0, limit=20) -> tuple[list[SyncLog], int]:
        stmt = select(SyncLog)
        if integration_type:
            stmt = stmt.where(SyncLog.integration_type == integration_type)
        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(SyncLog.started_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def create(self, **fields) -> SyncLog:
        row = SyncLog(**fields)
        self.db.add(row)
        self.db.commit()
        self.db.refresh(row)
        return row
