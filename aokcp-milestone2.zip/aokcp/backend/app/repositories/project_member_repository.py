import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.models.project_member import ProjectMember


class ProjectMemberRepository:
    def __init__(self, db: Session):
        self.db = db

    def list_for_project(self, project_id: uuid.UUID) -> list[ProjectMember]:
        stmt = (
            select(ProjectMember)
            .where(ProjectMember.project_id == project_id)
            .options(joinedload(ProjectMember.employee))
        )
        return list(self.db.execute(stmt).scalars())

    def list_for_employee(self, employee_id: uuid.UUID) -> list[ProjectMember]:
        stmt = (
            select(ProjectMember)
            .where(ProjectMember.employee_id == employee_id)
            .options(joinedload(ProjectMember.project))
        )
        return list(self.db.execute(stmt).scalars())

    def get(self, project_id: uuid.UUID, employee_id: uuid.UUID) -> ProjectMember | None:
        stmt = select(ProjectMember).where(
            ProjectMember.project_id == project_id, ProjectMember.employee_id == employee_id
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def add(self, **fields) -> ProjectMember:
        member = ProjectMember(**fields)
        self.db.add(member)
        self.db.commit()
        self.db.refresh(member)
        return member

    def remove(self, member: ProjectMember) -> None:
        self.db.delete(member)
        self.db.commit()
