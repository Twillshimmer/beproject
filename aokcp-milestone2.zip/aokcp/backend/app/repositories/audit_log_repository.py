import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


class AuditLogRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(
        self, *, user_id: uuid.UUID | None = None, resource_type: str | None = None,
        action: str | None = None, offset: int = 0, limit: int = 20,
    ) -> tuple[list[AuditLog], int]:
        stmt = select(AuditLog)
        if user_id is not None:
            stmt = stmt.where(AuditLog.user_id == user_id)
        if resource_type:
            stmt = stmt.where(AuditLog.resource_type == resource_type)
        if action:
            stmt = stmt.where(AuditLog.action == action)

        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(AuditLog.occurred_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total
