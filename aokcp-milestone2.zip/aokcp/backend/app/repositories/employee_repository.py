import uuid

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models.employee import Employee
from app.models.project_member import ProjectMember


class EmployeeRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(
        self,
        *,
        query: str | None,
        department_id: uuid.UUID | None,
        project_id: uuid.UUID | None,
        status_filter: str | None,
        offset: int,
        limit: int,
    ) -> tuple[list[Employee], int]:
        stmt = select(Employee)
        if project_id is not None:
            stmt = stmt.join(ProjectMember, ProjectMember.employee_id == Employee.id).where(
                ProjectMember.project_id == project_id
            )
        if query:
            like = f"%{query}%"
            stmt = stmt.where(or_(Employee.full_name.ilike(like), Employee.email.ilike(like)))
        if department_id is not None:
            stmt = stmt.where(Employee.department_id == department_id)
        if status_filter:
            stmt = stmt.where(Employee.status == status_filter)

        total = self.db.execute(
            select(func.count()).select_from(stmt.subquery())
        ).scalar_one()

        stmt = stmt.order_by(Employee.full_name).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def get(self, employee_id: uuid.UUID) -> Employee | None:
        return self.db.get(Employee, employee_id)

    def get_by_email(self, email: str) -> Employee | None:
        stmt = select(Employee).where(Employee.email == email)
        return self.db.execute(stmt).scalar_one_or_none()

    def create(self, **fields) -> Employee:
        employee = Employee(**fields)
        self.db.add(employee)
        self.db.commit()
        self.db.refresh(employee)
        return employee

    def update(self, employee: Employee, **fields) -> Employee:
        for key, value in fields.items():
            if value is not None:
                setattr(employee, key, value)
        self.db.commit()
        self.db.refresh(employee)
        return employee
