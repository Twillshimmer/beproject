import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.document import Document


class DocumentRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(
        self, *, project_id=None, department_id=None, offset=0, limit=20
    ) -> tuple[list[Document], int]:
        stmt = select(Document)
        if project_id is not None:
            stmt = stmt.where(Document.project_id == project_id)
        if department_id is not None:
            stmt = stmt.where(Document.department_id == department_id)

        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(Document.created_at.desc()).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def get(self, document_id: uuid.UUID) -> Document | None:
        return self.db.get(Document, document_id)

    def create(self, **fields) -> Document:
        document = Document(**fields)
        self.db.add(document)
        self.db.commit()
        self.db.refresh(document)
        return document

    def delete(self, document: Document) -> None:
        self.db.delete(document)
        self.db.commit()
