from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.integration_config import IntegrationConfig


class IntegrationConfigRepository:
    def __init__(self, db: Session):
        self.db = db

    def list_all(self) -> list[IntegrationConfig]:
        return list(self.db.execute(select(IntegrationConfig).order_by(IntegrationConfig.type)).scalars())

    def get_by_type(self, integration_type: str) -> IntegrationConfig | None:
        stmt = select(IntegrationConfig).where(IntegrationConfig.type == integration_type)
        return self.db.execute(stmt).scalar_one_or_none()

    def upsert(self, *, type: str, mode: str, config: dict | None = None) -> IntegrationConfig:
        existing = self.get_by_type(type)
        if existing:
            existing.mode = mode
            if config is not None:
                existing.config = config
            self.db.commit()
            self.db.refresh(existing)
            return existing
        row = IntegrationConfig(type=type, mode=mode, config=config or {})
        self.db.add(row)
        self.db.commit()
        self.db.refresh(row)
        return row

    def update(self, row: IntegrationConfig, **fields) -> IntegrationConfig:
        for key, value in fields.items():
            if value is not None:
                setattr(row, key, value)
        self.db.commit()
        self.db.refresh(row)
        return row
