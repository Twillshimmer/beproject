import uuid

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models.project import Project


class ProjectRepository:
    def __init__(self, db: Session):
        self.db = db

    def search(
        self,
        *,
        query: str | None,
        department_id: uuid.UUID | None,
        status_filter: str | None,
        offset: int,
        limit: int,
    ) -> tuple[list[Project], int]:
        stmt = select(Project)
        if query:
            like = f"%{query}%"
            stmt = stmt.where(or_(Project.name.ilike(like), Project.key.ilike(like)))
        if department_id is not None:
            stmt = stmt.where(Project.department_id == department_id)
        if status_filter:
            stmt = stmt.where(Project.status == status_filter)

        total = self.db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
        stmt = stmt.order_by(Project.name).offset(offset).limit(limit)
        items = list(self.db.execute(stmt).scalars())
        return items, total

    def get(self, project_id: uuid.UUID) -> Project | None:
        return self.db.get(Project, project_id)

    def get_by_key(self, key: str) -> Project | None:
        stmt = select(Project).where(Project.key == key)
        return self.db.execute(stmt).scalar_one_or_none()

    def create(self, **fields) -> Project:
        project = Project(**fields)
        self.db.add(project)
        self.db.commit()
        self.db.refresh(project)
        return project

    def update(self, project: Project, **fields) -> Project:
        for key, value in fields.items():
            if value is not None:
                setattr(project, key, value)
        self.db.commit()
        self.db.refresh(project)
        return project
