from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.integration import IntegrationConfigOut, IntegrationConfigUpdate, SyncLogOut
from app.schemas.pagination import PageParams, page_params
from app.services.integration_service import IntegrationService

router = APIRouter(prefix="/integrations", tags=["integrations"])


@router.get("", response_model=list[IntegrationConfigOut])
def list_integrations(db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    return IntegrationService(db).list_integrations()


@router.get("/{integration_type}", response_model=IntegrationConfigOut)
def get_integration(
    integration_type: str, db: Session = Depends(get_db), _: User = Depends(require_role("admin"))
):
    entry = IntegrationService(db).get_integration(integration_type)
    if entry is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found")
    return entry


@router.patch("/{integration_type}", response_model=IntegrationConfigOut)
def update_integration(
    integration_type: str, payload: IntegrationConfigUpdate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    return IntegrationService(db).update_integration(
        actor=actor, integration_type=integration_type, **payload.model_dump()
    )


@router.get("/{integration_type}/sync-logs", response_model=list[SyncLogOut])
def list_sync_logs(
    integration_type: str, pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db), _: User = Depends(require_role("admin")),
):
    items, _total = IntegrationService(db).list_sync_logs(
        integration_type=integration_type, offset=pagination.offset, limit=pagination.page_size
    )
    return items
