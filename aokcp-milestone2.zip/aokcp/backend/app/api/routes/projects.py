import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.pagination import PageParams, page_params
from app.schemas.project import (
    PaginatedProjects,
    ProjectCreate,
    ProjectMemberCreate,
    ProjectMemberOut,
    ProjectOut,
    ProjectUpdate,
)
from app.services.project_service import ProjectError, ProjectNotFoundError, ProjectService

router = APIRouter(prefix="/projects", tags=["projects"])


@router.get("", response_model=PaginatedProjects)
def list_projects(
    q: str | None = Query(default=None),
    department_id: uuid.UUID | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    items, total = ProjectService(db).search_projects(
        query=q, department_id=department_id, status_filter=status_filter,
        offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedProjects(items=items, total=total, page=pagination.page, page_size=pagination.page_size)


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(project_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    try:
        return ProjectService(db).get_project(project_id)
    except ProjectNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(
    payload: ProjectCreate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        return ProjectService(db).create_project(actor=actor, **payload.model_dump())
    except ProjectError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.patch("/{project_id}", response_model=ProjectOut)
def update_project(
    project_id: uuid.UUID, payload: ProjectUpdate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin", "manager")),
):
    try:
        return ProjectService(db).update_project(actor=actor, project_id=project_id, **payload.model_dump())
    except ProjectNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.get("/{project_id}/members", response_model=list[ProjectMemberOut])
def list_members(project_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    try:
        return ProjectService(db).list_members(project_id)
    except ProjectNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("/{project_id}/members", response_model=ProjectMemberOut, status_code=status.HTTP_201_CREATED)
def add_member(
    project_id: uuid.UUID, payload: ProjectMemberCreate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin", "manager")),
):
    try:
        return ProjectService(db).add_member(actor=actor, project_id=project_id, **payload.model_dump())
    except ProjectNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except ProjectError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.delete("/{project_id}/members/{employee_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_member(
    project_id: uuid.UUID, employee_id: uuid.UUID, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin", "manager")),
):
    try:
        ProjectService(db).remove_member(actor=actor, project_id=project_id, employee_id=employee_id)
    except ProjectError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
