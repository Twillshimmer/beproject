import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.document import DocumentOut, PaginatedDocuments
from app.schemas.pagination import PageParams, page_params
from app.services.document_service import (
    DocumentError,
    DocumentNotFoundError,
    DocumentService,
    DocumentValidationError,
)

router = APIRouter(prefix="/documents", tags=["documents"])


@router.get("", response_model=PaginatedDocuments)
def list_documents(
    project_id: uuid.UUID | None = None,
    department_id: uuid.UUID | None = None,
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    items, total = DocumentService(db).search_documents(
        project_id=project_id, department_id=department_id,
        offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedDocuments(items=items, total=total, page=pagination.page, page_size=pagination.page_size)


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(document_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    try:
        return DocumentService(db).get_document(document_id)
    except DocumentNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    title: str | None = Form(default=None),
    project_id: uuid.UUID | None = Form(default=None),
    department_id: uuid.UUID | None = Form(default=None),
    db: Session = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    service = DocumentService(db)
    content = await file.read()
    try:
        file_type = service.validate_upload(filename=file.filename, size_bytes=len(content))
    except DocumentValidationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    return service.store_upload(
        actor=actor, filename=file.filename, file_type=file_type, content=content,
        title=title, project_id=project_id, department_id=department_id,
    )


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: uuid.UUID, db: Session = Depends(get_db), actor: User = Depends(get_current_user)
):
    try:
        DocumentService(db).delete_document(actor=actor, document_id=document_id)
    except DocumentNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
