import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.department import DepartmentCreate, DepartmentOut, DepartmentUpdate
from app.services.department_service import (
    DepartmentError,
    DepartmentNotFoundError,
    DepartmentService,
)

router = APIRouter(prefix="/departments", tags=["departments"])


@router.get("", response_model=list[DepartmentOut])
def list_departments(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return DepartmentService(db).list_departments()


@router.get("/{department_id}", response_model=DepartmentOut)
def get_department(
    department_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)
):
    try:
        return DepartmentService(db).get_department(department_id)
    except DepartmentNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("", response_model=DepartmentOut, status_code=status.HTTP_201_CREATED)
def create_department(
    payload: DepartmentCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        return DepartmentService(db).create_department(actor=actor, **payload.model_dump())
    except DepartmentError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.patch("/{department_id}", response_model=DepartmentOut)
def update_department(
    department_id: uuid.UUID,
    payload: DepartmentUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        return DepartmentService(db).update_department(
            actor=actor, department_id=department_id, **payload.model_dump()
        )
    except DepartmentNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.delete("/{department_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_department(
    department_id: uuid.UUID,
    db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        DepartmentService(db).delete_department(actor=actor, department_id=department_id)
    except DepartmentNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
