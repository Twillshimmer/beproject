import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.employee import (
    EmployeeCreate,
    EmployeeOut,
    EmployeeUpdate,
    PaginatedEmployees,
)
from app.schemas.pagination import PageParams, page_params
from app.schemas.project import EmployeeProjectOut
from app.repositories.project_member_repository import ProjectMemberRepository
from app.services.employee_service import (
    EmployeeError,
    EmployeeNotFoundError,
    EmployeeService,
)

router = APIRouter(prefix="/employees", tags=["employees"])


@router.get("", response_model=PaginatedEmployees)
def list_employees(
    q: str | None = Query(default=None, description="Search by name or email"),
    department_id: uuid.UUID | None = None,
    project_id: uuid.UUID | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    items, total = EmployeeService(db).search_employees(
        query=q,
        department_id=department_id,
        project_id=project_id,
        status_filter=status_filter,
        offset=pagination.offset,
        limit=pagination.page_size,
    )
    return PaginatedEmployees(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size
    )


@router.get("/{employee_id}", response_model=EmployeeOut)
def get_employee(
    employee_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)
):
    try:
        return EmployeeService(db).get_employee(employee_id)
    except EmployeeNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("", response_model=EmployeeOut, status_code=status.HTTP_201_CREATED)
def create_employee(
    payload: EmployeeCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin")),
):
    try:
        return EmployeeService(db).create_employee(actor=actor, **payload.model_dump())
    except EmployeeError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.get("/{employee_id}/projects", response_model=list[EmployeeProjectOut])
def get_employee_projects(
    employee_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)
):
    try:
        EmployeeService(db).get_employee(employee_id)
    except EmployeeNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    return ProjectMemberRepository(db).list_for_employee(employee_id)


@router.patch("/{employee_id}", response_model=EmployeeOut)
def update_employee(
    employee_id: uuid.UUID,
    payload: EmployeeUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin", "manager")),
):
    try:
        return EmployeeService(db).update_employee(
            actor=actor, employee_id=employee_id, **payload.model_dump()
        )
    except EmployeeNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
