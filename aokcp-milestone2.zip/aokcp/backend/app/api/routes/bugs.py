import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.pagination import PageParams, page_params
from app.schemas.task import PaginatedBugs
from app.services.task_service import TaskService

router = APIRouter(prefix="/bugs", tags=["bugs"])


@router.get("", response_model=PaginatedBugs)
def list_bugs(
    project_id: uuid.UUID | None = None,
    severity: str | None = None,
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    items, total = TaskService(db).search_bugs(
        project_id=project_id, severity=severity, offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedBugs(items=items, total=total, page=pagination.page, page_size=pagination.page_size)
