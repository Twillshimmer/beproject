import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth.dependencies import require_role
from app.db.session import get_db
from app.models.user import User
from app.repositories.audit_log_repository import AuditLogRepository
from app.schemas.audit_log import PaginatedAuditLogs
from app.schemas.pagination import PageParams, page_params

router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])


@router.get("", response_model=PaginatedAuditLogs)
def list_audit_logs(
    user_id: uuid.UUID | None = None,
    resource_type: str | None = None,
    action: str | None = None,
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(require_role("admin")),
):
    items, total = AuditLogRepository(db).search(
        user_id=user_id, resource_type=resource_type, action=action,
        offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedAuditLogs(items=items, total=total, page=pagination.page, page_size=pagination.page_size)
