from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user
from app.db.session import get_db
from app.models.bug import Bug
from app.models.document import Document
from app.models.employee import Employee
from app.models.integration_config import IntegrationConfig
from app.models.project import Project
from app.models.task import Task
from app.models.user import User
from app.schemas.dashboard import DashboardStats

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/stats", response_model=DashboardStats)
def dashboard_stats(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    def count(stmt) -> int:
        return db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()

    return DashboardStats(
        total_employees=count(select(Employee)),
        active_employees=count(select(Employee).where(Employee.status == "active")),
        total_projects=count(select(Project)),
        active_projects=count(select(Project).where(Project.status == "active")),
        open_tasks=count(select(Task).where(Task.status != "done", Task.type != "bug")),
        open_bugs=count(
            select(Bug).join(Task, Bug.task_id == Task.id).where(Task.status != "done")
        ),
        total_documents=count(select(Document)),
        connected_integrations=count(
            select(IntegrationConfig).where(IntegrationConfig.is_enabled.is_(True))
        ),
    )
