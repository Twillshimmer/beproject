import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_role
from app.db.session import get_db
from app.models.user import User
from app.schemas.pagination import PageParams, page_params
from app.schemas.task import PaginatedTasks, TaskCreate, TaskOut, TaskUpdate
from app.services.task_service import TaskError, TaskNotFoundError, TaskService

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.get("", response_model=PaginatedTasks)
def list_tasks(
    project_id: uuid.UUID | None = None,
    assignee_id: uuid.UUID | None = None,
    status_filter: str | None = None,
    pagination: PageParams = Depends(page_params),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    items, total = TaskService(db).search_tasks(
        project_id=project_id, assignee_id=assignee_id, status_filter=status_filter,
        type_filter="task", offset=pagination.offset, limit=pagination.page_size,
    )
    return PaginatedTasks(items=items, total=total, page=pagination.page, page_size=pagination.page_size)


@router.get("/{task_id}", response_model=TaskOut)
def get_task(task_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    try:
        return TaskService(db).get_task(task_id)
    except TaskNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.post("", response_model=TaskOut, status_code=status.HTTP_201_CREATED)
def create_task(
    payload: TaskCreate, db: Session = Depends(get_db),
    actor: User = Depends(require_role("admin", "manager")),
):
    return TaskService(db).create_task(actor=actor, **payload.model_dump())


@router.patch("/{task_id}", response_model=TaskOut)
def update_task(
    task_id: uuid.UUID, payload: TaskUpdate, db: Session = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    try:
        return TaskService(db).update_task(actor=actor, task_id=task_id, **payload.model_dump())
    except TaskNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
