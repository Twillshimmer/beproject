import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class IntegrationConfigOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    type: str
    mode: str
    config: dict
    is_enabled: bool
    last_synced_at: datetime | None


class IntegrationConfigUpdate(BaseModel):
    is_enabled: bool | None = None
    config: dict | None = None


class SyncLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    integration_type: str
    status: str
    started_at: datetime
    finished_at: datetime | None
    records_synced: int
    errors: list
    triggered_by: uuid.UUID | None
