import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    title: str
    filename: str
    file_type: str
    size_bytes: int
    status: str
    uploaded_by: uuid.UUID
    project_id: uuid.UUID | None
    department_id: uuid.UUID | None
    created_at: datetime


class PaginatedDocuments(BaseModel):
    items: list[DocumentOut]
    total: int
    page: int
    page_size: int
