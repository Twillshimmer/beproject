from pydantic import BaseModel


class DashboardStats(BaseModel):
    total_employees: int
    active_employees: int
    total_projects: int
    active_projects: int
    open_tasks: int
    open_bugs: int
    total_documents: int
    connected_integrations: int
