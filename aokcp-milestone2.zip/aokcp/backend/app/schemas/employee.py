import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.schemas.department import DepartmentOut


class EmployeeCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=255)
    email: EmailStr
    title: str | None = None
    department_id: uuid.UUID | None = None
    manager_id: uuid.UUID | None = None
    hire_date: date | None = None
    github_username: str | None = None
    jira_account_id: str | None = None


class EmployeeUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    title: str | None = None
    department_id: uuid.UUID | None = None
    manager_id: uuid.UUID | None = None
    status: str | None = None
    left_date: date | None = None
    github_username: str | None = None
    jira_account_id: str | None = None


class EmployeeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    full_name: str
    email: EmailStr
    title: str | None
    status: str
    hire_date: date | None
    left_date: date | None
    github_username: str | None
    jira_account_id: str | None
    department_id: uuid.UUID | None
    manager_id: uuid.UUID | None
    created_at: datetime


class EmployeeDetailOut(EmployeeOut):
    department: DepartmentOut | None = None


class PaginatedEmployees(BaseModel):
    items: list[EmployeeOut]
    total: int
    page: int
    page_size: int
