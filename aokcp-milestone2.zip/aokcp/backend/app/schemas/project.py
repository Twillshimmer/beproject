import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.employee import EmployeeOut


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    key: str = Field(min_length=1, max_length=20)
    description: str | None = None
    department_id: uuid.UUID | None = None
    repository_url: str | None = None


class ProjectUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = None
    status: str | None = None
    department_id: uuid.UUID | None = None
    repository_url: str | None = None


class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    key: str
    description: str | None
    status: str
    repository_url: str | None
    department_id: uuid.UUID | None
    created_at: datetime


class PaginatedProjects(BaseModel):
    items: list[ProjectOut]
    total: int
    page: int
    page_size: int


class ProjectMemberCreate(BaseModel):
    employee_id: uuid.UUID
    role_on_project: str | None = None
    joined_at: date | None = None


class ProjectMemberOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    employee_id: uuid.UUID
    role_on_project: str | None
    joined_at: date | None
    left_at: date | None
    employee: EmployeeOut


class EmployeeProjectOut(BaseModel):
    """A project as seen from an employee's membership list."""

    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    role_on_project: str | None
    joined_at: date | None
    left_at: date | None
    project: ProjectOut

