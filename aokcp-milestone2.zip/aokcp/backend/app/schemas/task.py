import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class TaskCreate(BaseModel):
    project_id: uuid.UUID
    title: str = Field(min_length=1, max_length=500)
    description: str | None = None
    priority: str = "medium"
    type: str = "task"  # task | story | bug
    assignee_id: uuid.UUID | None = None
    # Only used when type == "bug"
    severity: str | None = None


class TaskUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    status: str | None = None
    priority: str | None = None
    assignee_id: uuid.UUID | None = None


class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    external_id: str | None
    title: str
    description: str | None
    status: str
    priority: str
    type: str
    source: str
    assignee_id: uuid.UUID | None
    created_at: datetime


class BugOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    task_id: uuid.UUID
    severity: str
    resolution: str | None
    task: TaskOut


class PaginatedTasks(BaseModel):
    items: list[TaskOut]
    total: int
    page: int
    page_size: int


class PaginatedBugs(BaseModel):
    items: list[BugOut]
    total: int
    page: int
    page_size: int
