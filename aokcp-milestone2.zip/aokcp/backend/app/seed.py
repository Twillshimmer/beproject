"""Seed baseline + sample data so the platform is fully demonstrable with
zero external credentials. Run with `python -m app.seed` (idempotent — safe
to run multiple times; skips anything that already exists).

Milestone 1: roles + default admin.
Milestone 2: sample departments, employees, projects, project members,
tasks, bugs, and default (mock-mode) integration config rows.
Milestone 3+: mock Jira/GitHub sample data will be added by their own
sync services rather than here, since that data must flow through the
same code path as a real sync.
"""
import logging
from datetime import date

from app.auth.security import hash_password
from app.db.session import SessionLocal
from app.models.department import Department
from app.models.employee import Employee
from app.models.integration_config import IntegrationConfig
from app.models.project import Project
from app.models.project_member import ProjectMember
from app.models.role import Role
from app.models.task import Task
from app.models.bug import Bug
from app.models.user import User

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aokcp.seed")

ROLES = ["admin", "manager", "employee"]
DEFAULT_ADMIN_EMAIL = "admin@aokcp.local"
DEFAULT_ADMIN_PASSWORD = "ChangeMe123!"


def seed_roles(db) -> dict[str, Role]:
    existing = {r.name: r for r in db.query(Role).all()}
    for name in ROLES:
        if name not in existing:
            role = Role(name=name, description=f"{name.capitalize()} role")
            db.add(role)
            existing[name] = role
    db.commit()
    return {r.name: r for r in db.query(Role).all()}


def seed_admin(db, roles: dict[str, Role]) -> None:
    if db.query(User).filter(User.email == DEFAULT_ADMIN_EMAIL).first():
        logger.info("Admin user already exists, skipping.")
        return
    admin = User(
        email=DEFAULT_ADMIN_EMAIL,
        hashed_password=hash_password(DEFAULT_ADMIN_PASSWORD),
        full_name="Platform Administrator",
        role=roles["admin"],
    )
    db.add(admin)
    db.commit()
    logger.info(
        "Created default admin: %s / %s (change this password immediately)",
        DEFAULT_ADMIN_EMAIL,
        DEFAULT_ADMIN_PASSWORD,
    )


def seed_departments(db) -> dict[str, Department]:
    names = ["Platform Engineering", "Product", "Data & AI", "Customer Success"]
    existing = {d.name: d for d in db.query(Department).all()}
    for name in names:
        if name not in existing:
            dept = Department(name=name, description=f"{name} department")
            db.add(dept)
            existing[name] = dept
    db.commit()
    return {d.name: d for d in db.query(Department).all()}


def seed_employees(db, departments: dict[str, Department]) -> dict[str, Employee]:
    sample = [
        # (full_name, email, title, department, github_username)
        ("Alicia Ferreira", "alicia.ferreira@aokcp.demo", "Staff Engineer", "Platform Engineering", "aferreira"),
        ("Daniel Osei", "daniel.osei@aokcp.demo", "Backend Engineer", "Platform Engineering", "dosei"),
        ("Meera Krishnan", "meera.krishnan@aokcp.demo", "Engineering Manager", "Platform Engineering", "mkrishnan"),
        ("Tom Reyes", "tom.reyes@aokcp.demo", "Product Manager", "Product", "treyes"),
        ("Yuki Tanaka", "yuki.tanaka@aokcp.demo", "ML Engineer", "Data & AI", "ytanaka"),
        ("Priya Nair", "priya.nair@aokcp.demo", "Data Engineer", "Data & AI", "pnair"),
        ("Chidi Okafor", "chidi.okafor@aokcp.demo", "Support Lead", "Customer Success", "cokafor"),
    ]
    existing = {e.email: e for e in db.query(Employee).all()}
    for full_name, email, title, dept_name, gh in sample:
        if email not in existing:
            emp = Employee(
                full_name=full_name,
                email=email,
                title=title,
                department_id=departments[dept_name].id,
                github_username=gh,
                hire_date=date(2023, 1, 15),
                status="active",
            )
            db.add(emp)
            existing[email] = emp
    db.commit()
    existing = {e.email: e for e in db.query(Employee).all()}

    # Manager relationships (Meera manages the two engineers).
    meera = existing["meera.krishnan@aokcp.demo"]
    for email in ("alicia.ferreira@aokcp.demo", "daniel.osei@aokcp.demo"):
        existing[email].manager_id = meera.id
    departments["Platform Engineering"].manager_employee_id = meera.id
    db.commit()
    return existing


def seed_projects(db, departments: dict[str, Department]) -> dict[str, Project]:
    sample = [
        ("Payment Platform", "PAY", "Payments processing and reconciliation services", "Platform Engineering",
         "https://github.com/aokcp-demo/payment-platform"),
        ("Notification Service", "NOTIF", "Multi-channel notification delivery", "Platform Engineering",
         "https://github.com/aokcp-demo/notification-service"),
        ("Customer Insights", "INSIGHT", "ML-driven customer analytics", "Data & AI",
         "https://github.com/aokcp-demo/customer-insights"),
    ]
    existing = {p.key: p for p in db.query(Project).all()}
    for name, key, desc, dept_name, repo in sample:
        if key not in existing:
            project = Project(
                name=name, key=key, description=desc, status="active",
                department_id=departments[dept_name].id, repository_url=repo,
            )
            db.add(project)
            existing[key] = project
    db.commit()
    return {p.key: p for p in db.query(Project).all()}


def seed_project_members(db, employees: dict[str, Employee], projects: dict[str, Project]) -> None:
    memberships = [
        ("PAY", "alicia.ferreira@aokcp.demo", "Tech Lead"),
        ("PAY", "daniel.osei@aokcp.demo", "Contributor"),
        ("NOTIF", "daniel.osei@aokcp.demo", "Contributor"),
        ("INSIGHT", "yuki.tanaka@aokcp.demo", "Tech Lead"),
        ("INSIGHT", "priya.nair@aokcp.demo", "Contributor"),
    ]
    existing_pairs = {
        (m.project_id, m.employee_id) for m in db.query(ProjectMember).all()
    }
    for project_key, email, role_on_project in memberships:
        project = projects[project_key]
        employee = employees[email]
        if (project.id, employee.id) not in existing_pairs:
            db.add(ProjectMember(
                project_id=project.id, employee_id=employee.id,
                role_on_project=role_on_project, joined_at=date(2023, 2, 1),
            ))
    db.commit()


def seed_tasks_and_bugs(db, employees: dict[str, Employee], projects: dict[str, Project]) -> None:
    if db.query(Task).count() > 0:
        logger.info("Tasks already seeded, skipping.")
        return

    tasks = [
        ("PAY", "Reconcile settlement report mismatches", "task", "high", "alicia.ferreira@aokcp.demo", "in_progress"),
        ("PAY", "Add idempotency keys to charge API", "task", "medium", "daniel.osei@aokcp.demo", "open"),
        ("NOTIF", "Migrate SMS provider integration", "task", "medium", "daniel.osei@aokcp.demo", "open"),
        ("INSIGHT", "Build churn-risk scoring model v2", "task", "high", "yuki.tanaka@aokcp.demo", "in_progress"),
    ]
    for project_key, title, type_, priority, email, status_ in tasks:
        db.add(Task(
            project_id=projects[project_key].id, title=title, type=type_, priority=priority,
            assignee_id=employees[email].id, status=status_, source="manual",
        ))
    db.commit()

    bugs = [
        ("PAY", "Duplicate charge on retried webhook", "high", "alicia.ferreira@aokcp.demo", "open"),
        ("INSIGHT", "Model scoring endpoint times out on large batches", "medium", "priya.nair@aokcp.demo", "open"),
    ]
    for project_key, title, severity, email, status_ in bugs:
        task = Task(
            project_id=projects[project_key].id, title=title, type="bug", priority=severity,
            assignee_id=employees[email].id, status=status_, source="manual",
        )
        db.add(task)
        db.flush()  # get task.id without a full commit
        db.add(Bug(task_id=task.id, severity=severity))
    db.commit()


def seed_integration_configs(db) -> None:
    from app.core.config import get_settings
    settings = get_settings()

    defaults = [
        ("jira", "live" if settings.jira_configured else "mock"),
        ("github", "live" if settings.github_configured else "mock"),
        ("hr", "mock"),
        ("documents", "mock"),
    ]
    existing = {c.type for c in db.query(IntegrationConfig).all()}
    for integration_type, mode in defaults:
        if integration_type not in existing:
            db.add(IntegrationConfig(type=integration_type, mode=mode, config={}, is_enabled=True))
    db.commit()


def main() -> None:
    db = SessionLocal()
    try:
        roles = seed_roles(db)
        seed_admin(db, roles)
        departments = seed_departments(db)
        employees = seed_employees(db, departments)
        projects = seed_projects(db, departments)
        seed_project_members(db, employees, projects)
        seed_tasks_and_bugs(db, employees, projects)
        seed_integration_configs(db)
        logger.info("Seed complete.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
