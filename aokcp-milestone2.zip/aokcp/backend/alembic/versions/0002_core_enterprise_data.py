"""core enterprise data: departments, employees, projects, project_members,
tasks, bugs, documents, integration_configs, sync_logs, audit_logs,
identity_mappings; adds users.employee_id

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-14

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- departments ---
    op.create_table(
        "departments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("manager_employee_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.UniqueConstraint("name", name="uq_departments_name"),
    )
    op.create_index("ix_departments_name", "departments", ["name"])

    # --- employees ---
    op.create_table(
        "employees",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("full_name", sa.String(length=255), nullable=False),
        sa.Column("email", sa.String(length=255), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="active"),
        sa.Column("hire_date", sa.Date(), nullable=True),
        sa.Column("left_date", sa.Date(), nullable=True),
        sa.Column("github_username", sa.String(length=255), nullable=True),
        sa.Column("jira_account_id", sa.String(length=255), nullable=True),
        sa.Column("department_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("manager_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["department_id"], ["departments.id"], name="fk_employees_department_id"),
        sa.ForeignKeyConstraint(["manager_id"], ["employees.id"], name="fk_employees_manager_id"),
        sa.UniqueConstraint("email", name="uq_employees_email"),
    )
    for col in ("email", "status", "department_id", "manager_id", "github_username", "jira_account_id"):
        op.create_index(f"ix_employees_{col}", "employees", [col])

    op.create_foreign_key(
        "fk_departments_manager_employee_id",
        "departments",
        "employees",
        ["manager_employee_id"],
        ["id"],
    )

    # --- users.employee_id (added after employees exists) ---
    op.add_column("users", sa.Column("employee_id", postgresql.UUID(as_uuid=True), nullable=True))
    op.create_index("ix_users_employee_id", "users", ["employee_id"])
    op.create_foreign_key(
        "fk_users_employee_id", "users", "employees", ["employee_id"], ["id"]
    )

    # --- projects ---
    op.create_table(
        "projects",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("key", sa.String(length=20), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="active"),
        sa.Column("repository_url", sa.String(length=500), nullable=True),
        sa.Column("department_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["department_id"], ["departments.id"], name="fk_projects_department_id"),
        sa.UniqueConstraint("key", name="uq_projects_key"),
    )
    op.create_index("ix_projects_name", "projects", ["name"])
    op.create_index("ix_projects_key", "projects", ["key"])
    op.create_index("ix_projects_status", "projects", ["status"])
    op.create_index("ix_projects_department_id", "projects", ["department_id"])

    # --- project_members ---
    op.create_table(
        "project_members",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("employee_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("role_on_project", sa.String(length=100), nullable=True),
        sa.Column("joined_at", sa.Date(), nullable=True),
        sa.Column("left_at", sa.Date(), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_project_members_project_id"),
        sa.ForeignKeyConstraint(["employee_id"], ["employees.id"], name="fk_project_members_employee_id"),
        sa.UniqueConstraint("project_id", "employee_id", name="uq_project_member"),
    )
    op.create_index("ix_project_members_project_id", "project_members", ["project_id"])
    op.create_index("ix_project_members_employee_id", "project_members", ["employee_id"])

    # --- tasks ---
    op.create_table(
        "tasks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("external_id", sa.String(length=50), nullable=True),
        sa.Column("title", sa.String(length=500), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=50), nullable=False, server_default="open"),
        sa.Column("priority", sa.String(length=20), nullable=False, server_default="medium"),
        sa.Column("type", sa.String(length=20), nullable=False, server_default="task"),
        sa.Column("source", sa.String(length=20), nullable=False, server_default="manual"),
        sa.Column("assignee_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_at_source", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at_source", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_tasks_project_id"),
        sa.ForeignKeyConstraint(["assignee_id"], ["employees.id"], name="fk_tasks_assignee_id"),
        sa.UniqueConstraint("source", "external_id", name="uq_task_source_external_id"),
    )
    for col in ("project_id", "external_id", "status", "type", "assignee_id"):
        op.create_index(f"ix_tasks_{col}", "tasks", [col])

    # --- bugs ---
    op.create_table(
        "bugs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("task_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("severity", sa.String(length=20), nullable=False, server_default="medium"),
        sa.Column("resolution", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["task_id"], ["tasks.id"], name="fk_bugs_task_id"),
        sa.UniqueConstraint("task_id", name="uq_bugs_task_id"),
    )
    op.create_index("ix_bugs_task_id", "bugs", ["task_id"])
    op.create_index("ix_bugs_severity", "bugs", ["severity"])

    # --- documents ---
    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("title", sa.String(length=500), nullable=False),
        sa.Column("filename", sa.String(length=500), nullable=False),
        sa.Column("file_path", sa.String(length=1000), nullable=False),
        sa.Column("file_type", sa.String(length=20), nullable=False),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="processing"),
        sa.Column("uploaded_by", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("department_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["uploaded_by"], ["users.id"], name="fk_documents_uploaded_by"),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_documents_project_id"),
        sa.ForeignKeyConstraint(["department_id"], ["departments.id"], name="fk_documents_department_id"),
    )
    for col in ("status", "uploaded_by", "project_id", "department_id"):
        op.create_index(f"ix_documents_{col}", "documents", [col])

    # --- integration_configs ---
    op.create_table(
        "integration_configs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("type", sa.String(length=20), nullable=False),
        sa.Column("mode", sa.String(length=10), nullable=False, server_default="mock"),
        sa.Column("config", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("is_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("last_synced_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("type", name="uq_integration_configs_type"),
    )
    op.create_index("ix_integration_configs_type", "integration_configs", ["type"])

    # --- sync_logs ---
    op.create_table(
        "sync_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("integration_type", sa.String(length=20), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("records_synced", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("errors", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("triggered_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["triggered_by"], ["users.id"], name="fk_sync_logs_triggered_by"),
    )
    op.create_index("ix_sync_logs_integration_type", "sync_logs", ["integration_type"])
    op.create_index("ix_sync_logs_status", "sync_logs", ["status"])

    # --- audit_logs ---
    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("action", sa.String(length=100), nullable=False),
        sa.Column("resource_type", sa.String(length=50), nullable=False),
        sa.Column("resource_id", sa.String(length=100), nullable=True),
        sa.Column("log_metadata", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="success"),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ip_address", sa.String(length=64), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], name="fk_audit_logs_user_id"),
    )
    for col in ("user_id", "action", "resource_type"):
        op.create_index(f"ix_audit_logs_{col}", "audit_logs", [col])

    # --- identity_mappings ---
    op.create_table(
        "identity_mappings",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("external_system", sa.String(length=20), nullable=False),
        sa.Column("external_identifier", sa.String(length=255), nullable=False),
        sa.Column("employee_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="unresolved"),
        sa.Column("resolved_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["employee_id"], ["employees.id"], name="fk_identity_mappings_employee_id"),
        sa.ForeignKeyConstraint(["resolved_by"], ["users.id"], name="fk_identity_mappings_resolved_by"),
        sa.UniqueConstraint("external_system", "external_identifier", name="uq_identity_mapping"),
    )
    for col in ("external_system", "external_identifier", "employee_id", "status"):
        op.create_index(f"ix_identity_mappings_{col}", "identity_mappings", [col])


def downgrade() -> None:
    op.drop_table("identity_mappings")
    op.drop_table("audit_logs")
    op.drop_table("sync_logs")
    op.drop_table("integration_configs")
    op.drop_table("documents")
    op.drop_table("bugs")
    op.drop_table("tasks")
    op.drop_table("project_members")
    op.drop_table("projects")
    op.drop_constraint("fk_users_employee_id", "users", type_="foreignkey")
    op.drop_index("ix_users_employee_id", table_name="users")
    op.drop_column("users", "employee_id")
    op.drop_constraint("fk_departments_manager_employee_id", "departments", type_="foreignkey")
    op.drop_table("employees")
    op.drop_table("departments")
