import { apiClient } from "@/services/apiClient";
import type { AuditLogEntry, DashboardStats, Paginated } from "@/types/domain";

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const { data } = await apiClient.get<DashboardStats>("/dashboard/stats");
  return data;
}

export async function listAuditLogs(page = 1): Promise<Paginated<AuditLogEntry>> {
  const { data } = await apiClient.get<Paginated<AuditLogEntry>>("/audit-logs", {
    params: { page, page_size: 25 },
  });
  return data;
}
