import { apiClient } from "@/services/apiClient";
import type { Department } from "@/types/domain";

export async function listDepartments(): Promise<Department[]> {
  const { data } = await apiClient.get<Department[]>("/departments");
  return data;
}
