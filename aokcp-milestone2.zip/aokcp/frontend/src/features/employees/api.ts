import { apiClient } from "@/services/apiClient";
import type { Employee, Paginated } from "@/types/domain";

export interface EmployeeFilters {
  q?: string;
  department_id?: string;
  project_id?: string;
  status?: string;
  page?: number;
  page_size?: number;
}

export async function listEmployees(filters: EmployeeFilters = {}): Promise<Paginated<Employee>> {
  const { data } = await apiClient.get<Paginated<Employee>>("/employees", { params: filters });
  return data;
}

export async function getEmployee(id: string): Promise<Employee> {
  const { data } = await apiClient.get<Employee>(`/employees/${id}`);
  return data;
}

export async function getEmployeeProjects(id: string) {
  const { data } = await apiClient.get(`/employees/${id}/projects`);
  return data as Array<{
    id: string;
    project_id: string;
    role_on_project: string | null;
    joined_at: string | null;
    left_at: string | null;
    project: { id: string; name: string; key: string; status: string };
  }>;
}
