import { apiClient } from "@/services/apiClient";
import type { Paginated, Project, ProjectMember } from "@/types/domain";

export interface ProjectFilters {
  q?: string;
  department_id?: string;
  status?: string;
  page?: number;
  page_size?: number;
}

export async function listProjects(filters: ProjectFilters = {}): Promise<Paginated<Project>> {
  const { data } = await apiClient.get<Paginated<Project>>("/projects", { params: filters });
  return data;
}

export async function getProject(id: string): Promise<Project> {
  const { data } = await apiClient.get<Project>(`/projects/${id}`);
  return data;
}

export async function listProjectMembers(projectId: string): Promise<ProjectMember[]> {
  const { data } = await apiClient.get<ProjectMember[]>(`/projects/${projectId}/members`);
  return data;
}
