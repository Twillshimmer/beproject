import { apiClient } from "@/services/apiClient";
import type { Bug, Paginated, Task } from "@/types/domain";

export async function listTasks(projectId: string): Promise<Paginated<Task>> {
  const { data } = await apiClient.get<Paginated<Task>>("/tasks", {
    params: { project_id: projectId, page_size: 50 },
  });
  return data;
}

export async function listBugs(projectId: string): Promise<Paginated<Bug>> {
  const { data } = await apiClient.get<Paginated<Bug>>("/bugs", {
    params: { project_id: projectId, page_size: 50 },
  });
  return data;
}
