import { apiClient } from "@/services/apiClient";
import type { DocumentItem, Paginated } from "@/types/domain";

export async function listDocuments(params: {
  project_id?: string;
  page?: number;
  page_size?: number;
} = {}): Promise<Paginated<DocumentItem>> {
  const { data } = await apiClient.get<Paginated<DocumentItem>>("/documents", { params });
  return data;
}

export async function uploadDocument(file: File, title?: string): Promise<DocumentItem> {
  const form = new FormData();
  form.append("file", file);
  if (title) form.append("title", title);
  const { data } = await apiClient.post<DocumentItem>("/documents", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function deleteDocument(id: string): Promise<void> {
  await apiClient.delete(`/documents/${id}`);
}
