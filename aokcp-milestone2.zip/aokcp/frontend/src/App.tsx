import { Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AppLayout } from "@/layouts/AppLayout";
import { LoginPage } from "@/pages/LoginPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { EmployeesPage } from "@/pages/EmployeesPage";
import { EmployeeDetailPage } from "@/pages/EmployeeDetailPage";
import { ProjectsPage } from "@/pages/ProjectsPage";
import { ProjectDetailPage } from "@/pages/ProjectDetailPage";
import { DocumentsPage } from "@/pages/DocumentsPage";
import { AuditLogsPage } from "@/pages/AuditLogsPage";
import { ComingSoonPage } from "@/components/ComingSoonPage";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/employees" element={<EmployeesPage />} />
            <Route path="/employees/:id" element={<EmployeeDetailPage />} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/projects/:id" element={<ProjectDetailPage />} />
            <Route path="/documents" element={<DocumentsPage />} />
            <Route
              path="/knowledge-graph"
              element={<ComingSoonPage title="Knowledge Graph" milestone="Milestone 6" />}
            />
            <Route
              path="/assistant"
              element={<ComingSoonPage title="AI Assistant" milestone="Milestone 9" />}
            />
            <Route
              path="/handover"
              element={<ComingSoonPage title="Handover" milestone="Milestone 10" />}
            />
            <Route
              path="/integrations"
              element={
                <ComingSoonPage
                  title="Integrations"
                  milestone="Milestones 3 & 4 (sync actions); config viewer is planned next"
                />
              }
            />

            <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
              <Route path="/audit-logs" element={<AuditLogsPage />} />
            </Route>
          </Route>
        </Route>

        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AuthProvider>
  );
}
