export interface Department {
  id: string;
  name: string;
  description: string | null;
  manager_employee_id: string | null;
}

export interface Employee {
  id: string;
  full_name: string;
  email: string;
  title: string | null;
  status: "active" | "left";
  hire_date: string | null;
  left_date: string | null;
  github_username: string | null;
  jira_account_id: string | null;
  department_id: string | null;
  manager_id: string | null;
  created_at: string;
}

export interface Project {
  id: string;
  name: string;
  key: string;
  description: string | null;
  status: "active" | "inactive" | "archived";
  repository_url: string | null;
  department_id: string | null;
  created_at: string;
}

export interface ProjectMember {
  id: string;
  project_id: string;
  employee_id: string;
  role_on_project: string | null;
  joined_at: string | null;
  left_at: string | null;
  employee: Employee;
}

export interface Task {
  id: string;
  project_id: string;
  external_id: string | null;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  type: string;
  source: string;
  assignee_id: string | null;
  created_at: string;
}

export interface Bug {
  id: string;
  task_id: string;
  severity: string;
  resolution: string | null;
  task: Task;
}

export interface DocumentItem {
  id: string;
  title: string;
  filename: string;
  file_type: string;
  size_bytes: number;
  status: string;
  uploaded_by: string;
  project_id: string | null;
  department_id: string | null;
  created_at: string;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}

export interface DashboardStats {
  total_employees: number;
  active_employees: number;
  total_projects: number;
  active_projects: number;
  open_tasks: number;
  open_bugs: number;
  total_documents: number;
  connected_integrations: number;
}

export interface AuditLogEntry {
  id: string;
  user_id: string | null;
  action: string;
  resource_type: string;
  resource_id: string | null;
  log_metadata: Record<string, unknown>;
  status: string;
  occurred_at: string;
  ip_address: string | null;
}
