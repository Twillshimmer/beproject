import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Github } from "lucide-react";
import { getProject, listProjectMembers } from "@/features/projects/api";
import { listBugs, listTasks } from "@/features/projects/tasksApi";
import type { Bug, Project, ProjectMember, Task } from "@/types/domain";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { getApiErrorMessage } from "@/utils/errors";

type Tab = "members" | "tasks" | "bugs";

export function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [members, setMembers] = useState<ProjectMember[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [bugs, setBugs] = useState<Bug[]>([]);
  const [tab, setTab] = useState<Tab>("members");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setIsLoading(true);
    setError(null);
    Promise.all([getProject(id), listProjectMembers(id), listTasks(id), listBugs(id)])
      .then(([proj, mem, taskPage, bugPage]) => {
        setProject(proj);
        setMembers(mem);
        setTasks(taskPage.items);
        setBugs(bugPage.items);
      })
      .catch((err) => setError(getApiErrorMessage(err, "Could not load this project.")))
      .finally(() => setIsLoading(false));
  }, [id]);

  if (isLoading) return <SkeletonRows count={4} />;

  if (error) {
    return (
      <div className="space-y-4">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-slate-500">
          <ArrowLeft size={15} /> Back
        </button>
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>
      </div>
    );
  }

  if (!project) return null;

  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: "members", label: "Members", count: members.length },
    { key: "tasks", label: "Tasks", count: tasks.length },
    { key: "bugs", label: "Bugs", count: bugs.length },
  ];

  return (
    <div className="space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-slate-500">
        <ArrowLeft size={15} /> Back to projects
      </button>

      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-semibold text-slate-900">{project.name}</h1>
            <p className="text-sm text-slate-500">{project.key}</p>
          </div>
          <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
            {project.status}
          </span>
        </div>
        {project.description && <p className="mt-3 text-sm text-slate-600">{project.description}</p>}
        {project.repository_url && (
          <a
            href={project.repository_url}
            target="_blank"
            rel="noreferrer"
            className="mt-3 flex w-fit items-center gap-1.5 text-sm text-brand-600 hover:underline"
          >
            <Github size={14} /> {project.repository_url}
          </a>
        )}
      </div>

      <div>
        <div className="flex gap-1 border-b border-slate-200">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-3 py-2 text-sm font-medium ${
                tab === t.key
                  ? "border-b-2 border-brand-600 text-brand-700"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              {t.label} ({t.count})
            </button>
          ))}
        </div>

        <div className="mt-4">
          {tab === "members" &&
            (members.length === 0 ? (
              <EmptyState title="No members yet" />
            ) : (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
                {members.map((m) => (
                  <Link
                    key={m.id}
                    to={`/employees/${m.employee_id}`}
                    className="flex items-center justify-between px-4 py-3 text-sm hover:bg-slate-50"
                  >
                    <span className="font-medium text-slate-800">{m.employee.full_name}</span>
                    <span className="text-slate-500">{m.role_on_project ?? "Member"}</span>
                  </Link>
                ))}
              </div>
            ))}

          {tab === "tasks" &&
            (tasks.length === 0 ? (
              <EmptyState title="No open tasks" />
            ) : (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
                {tasks.map((t) => (
                  <div key={t.id} className="flex items-center justify-between px-4 py-3 text-sm">
                    <span className="text-slate-800">{t.title}</span>
                    <span className="flex gap-2">
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">
                        {t.priority}
                      </span>
                      <span className="rounded-full bg-blue-50 px-2 py-0.5 text-xs text-blue-700">
                        {t.status}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            ))}

          {tab === "bugs" &&
            (bugs.length === 0 ? (
              <EmptyState title="No open bugs" />
            ) : (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
                {bugs.map((b) => (
                  <div key={b.id} className="flex items-center justify-between px-4 py-3 text-sm">
                    <span className="text-slate-800">{b.task.title}</span>
                    <span className="rounded-full bg-red-50 px-2 py-0.5 text-xs text-red-700">
                      {b.severity}
                    </span>
                  </div>
                ))}
              </div>
            ))}
        </div>
      </div>

      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">
        Repositories, pull requests, technologies, documents, knowledge graph
        relationships, and the AI-generated project summary are planned for
        later milestones (M4–M9).
      </div>
    </div>
  );
}
