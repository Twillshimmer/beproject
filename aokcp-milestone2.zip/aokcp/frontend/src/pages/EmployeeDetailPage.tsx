import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Mail, Github } from "lucide-react";
import { getEmployee, getEmployeeProjects } from "@/features/employees/api";
import type { Employee } from "@/types/domain";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { getApiErrorMessage } from "@/utils/errors";

interface MembershipRow {
  id: string;
  project_id: string;
  role_on_project: string | null;
  project: { id: string; name: string; key: string; status: string };
}

export function EmployeeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [projects, setProjects] = useState<MembershipRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setIsLoading(true);
    setError(null);
    Promise.all([getEmployee(id), getEmployeeProjects(id)])
      .then(([emp, memberships]) => {
        setEmployee(emp);
        setProjects(memberships);
      })
      .catch((err) => setError(getApiErrorMessage(err, "Could not load this employee.")))
      .finally(() => setIsLoading(false));
  }, [id]);

  if (isLoading) return <SkeletonRows count={4} />;

  if (error) {
    return (
      <div className="space-y-4">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-slate-500">
          <ArrowLeft size={15} /> Back
        </button>
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>
      </div>
    );
  }

  if (!employee) return null;

  return (
    <div className="space-y-6">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-slate-500">
        <ArrowLeft size={15} /> Back to employees
      </button>

      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-semibold text-slate-900">{employee.full_name}</h1>
            <p className="text-sm text-slate-500">{employee.title ?? "No title on file"}</p>
          </div>
          <span
            className={`rounded-full px-2.5 py-1 text-xs font-medium ${
              employee.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"
            }`}
          >
            {employee.status}
          </span>
        </div>
        <div className="mt-4 flex flex-wrap gap-4 text-sm text-slate-500">
          <span className="flex items-center gap-1.5">
            <Mail size={14} /> {employee.email}
          </span>
          {employee.github_username && (
            <span className="flex items-center gap-1.5">
              <Github size={14} /> {employee.github_username}
            </span>
          )}
        </div>
      </div>

      <div>
        <h2 className="mb-2 text-sm font-semibold text-slate-700">Projects</h2>
        {projects.length === 0 ? (
          <EmptyState
            title="No project memberships"
            description="This employee is not currently assigned to any project."
          />
        ) : (
          <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
            {projects.map((m) => (
              <Link
                key={m.id}
                to={`/projects/${m.project_id}`}
                className="flex items-center justify-between px-4 py-3 text-sm hover:bg-slate-50"
              >
                <div>
                  <p className="font-medium text-slate-800">{m.project.name}</p>
                  <p className="text-xs text-slate-400">{m.project.key}</p>
                </div>
                <span className="text-slate-500">{m.role_on_project ?? "Member"}</span>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">
        Tasks, bugs, Jira/GitHub activity, technologies, documents, and the
        AI-generated Knowledge Profile for this employee are planned for
        later milestones (M3–M10).
      </div>
    </div>
  );
}
