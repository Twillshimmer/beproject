import { useEffect, useState } from "react";
import { listAuditLogs } from "@/features/dashboard/api";
import type { AuditLogEntry, Paginated } from "@/types/domain";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { Pagination } from "@/components/Pagination";
import { getApiErrorMessage } from "@/utils/errors";

export function AuditLogsPage() {
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Paginated<AuditLogEntry> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    setError(null);
    listAuditLogs(page)
      .then(setData)
      .catch((err) => setError(getApiErrorMessage(err, "Could not load audit logs.")))
      .finally(() => setIsLoading(false));
  }, [page]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-slate-900">Audit Logs</h1>

      {isLoading && <SkeletonRows />}

      {!isLoading && error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>
      )}

      {!isLoading && !error && data && data.items.length === 0 && (
        <EmptyState title="No audit activity yet" />
      )}

      {!isLoading && !error && data && data.items.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Action</th>
                <th className="px-4 py-3 font-medium">Resource</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Occurred at</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((entry) => (
                <tr key={entry.id} className="border-b border-slate-50 last:border-0">
                  <td className="px-4 py-3 font-medium text-slate-800">{entry.action}</td>
                  <td className="px-4 py-3 text-slate-500">
                    {entry.resource_type}
                    {entry.resource_id ? ` · ${entry.resource_id.slice(0, 8)}…` : ""}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        entry.status === "success"
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-red-50 text-red-700"
                      }`}
                    >
                      {entry.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500">
                    {new Date(entry.occurred_at).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-4">
            <Pagination page={page} pageSize={25} total={data.total} onPageChange={setPage} />
          </div>
        </div>
      )}
    </div>
  );
}
