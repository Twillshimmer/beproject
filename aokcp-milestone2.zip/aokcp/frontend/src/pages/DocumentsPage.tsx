import { useEffect, useRef, useState } from "react";
import { FileText, Loader2, Trash2, Upload } from "lucide-react";
import { deleteDocument, listDocuments, uploadDocument } from "@/features/documents/api";
import type { DocumentItem } from "@/types/domain";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { getApiErrorMessage } from "@/utils/errors";

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DocumentsPage() {
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function refresh() {
    setIsLoading(true);
    setError(null);
    listDocuments({ page_size: 50 })
      .then((data) => setDocuments(data.items))
      .catch((err) => setError(getApiErrorMessage(err, "Could not load documents.")))
      .finally(() => setIsLoading(false));
  }

  useEffect(refresh, []);

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError(null);
    setIsUploading(true);
    try {
      await uploadDocument(file);
      refresh();
    } catch (err) {
      setUploadError(getApiErrorMessage(err, "Upload failed."));
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleDelete(id: string) {
    await deleteDocument(id);
    setDocuments((prev) => prev.filter((d) => d.id !== id));
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-slate-900">Documents</h1>
        <label className="flex cursor-pointer items-center gap-2 rounded-lg bg-brand-600 px-3 py-2 text-sm font-medium text-white hover:bg-brand-700">
          {isUploading ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
          Upload document
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.docx,.txt,.md"
            className="hidden"
            onChange={handleFileSelected}
            disabled={isUploading}
          />
        </label>
      </div>

      <p className="text-xs text-slate-400">
        Accepted formats: PDF, DOCX, TXT, Markdown. Text extraction, chunking,
        embedding, and knowledge-graph linking are planned for Milestones 5 &
        7 — uploads are safely stored now, not yet processed.
      </p>

      {uploadError && (
        <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{uploadError}</div>
      )}

      {isLoading && <SkeletonRows />}

      {!isLoading && error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>
      )}

      {!isLoading && !error && documents.length === 0 && (
        <EmptyState
          title="No documents uploaded yet"
          description="Upload a PDF, DOCX, TXT, or Markdown file to get started."
        />
      )}

      {!isLoading && !error && documents.length > 0 && (
        <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
          {documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <div className="flex items-center gap-3">
                <FileText size={16} className="text-slate-400" />
                <div>
                  <p className="font-medium text-slate-800">{doc.title}</p>
                  <p className="text-xs text-slate-400">
                    {doc.filename} · {formatSize(doc.size_bytes)} ·{" "}
                    <span className="uppercase">{doc.file_type}</span> · {doc.status}
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleDelete(doc.id)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                title="Delete"
              >
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
