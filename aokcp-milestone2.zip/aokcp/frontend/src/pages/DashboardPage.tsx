import { useEffect, useState } from "react";
import { Bug, FileText, FolderKanban, ListChecks, PlugZap, Users } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { fetchDashboardStats } from "@/features/dashboard/api";
import type { DashboardStats } from "@/types/domain";
import { StatCard } from "@/components/StatCard";
import { SkeletonRows } from "@/components/SkeletonRows";
import { getApiErrorMessage } from "@/utils/errors";

export function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats()
      .then(setStats)
      .catch((err) => setError(getApiErrorMessage(err, "Could not load dashboard stats.")))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">
          Welcome back, {user?.full_name?.split(" ")[0]}
        </h1>
        <p className="text-sm text-slate-500">
          Signed in as <span className="font-medium">{user?.email}</span> ·{" "}
          <span className="capitalize">{user?.role.name}</span>
        </p>
      </div>

      {isLoading && <SkeletonRows count={2} />}

      {!isLoading && error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">
          {error}
        </div>
      )}

      {!isLoading && stats && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          <StatCard label="Employees" value={stats.total_employees} icon={Users} />
          <StatCard label="Active employees" value={stats.active_employees} icon={Users} />
          <StatCard label="Projects" value={stats.total_projects} icon={FolderKanban} />
          <StatCard label="Active projects" value={stats.active_projects} icon={FolderKanban} />
          <StatCard label="Open tasks" value={stats.open_tasks} icon={ListChecks} />
          <StatCard label="Open bugs" value={stats.open_bugs} icon={Bug} />
          <StatCard label="Documents" value={stats.total_documents} icon={FileText} />
          <StatCard label="Connected integrations" value={stats.connected_integrations} icon={PlugZap} />
        </div>
      )}

      <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">
        Charts (projects by department, tasks by status, bugs by priority) and
        the AI-powered features — knowledge graph, assistant, handover,
        onboarding, knowledge-gap detection — are planned for later
        milestones. See <span className="font-medium">IMPLEMENTATION_STATUS.md</span> for
        current progress.
      </div>
    </div>
  );
}
