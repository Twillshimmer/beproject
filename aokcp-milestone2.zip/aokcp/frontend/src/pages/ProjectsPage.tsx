import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { listProjects } from "@/features/projects/api";
import { listDepartments } from "@/features/departments/api";
import type { Department, Paginated, Project } from "@/types/domain";
import { SearchInput } from "@/components/SearchInput";
import { SkeletonRows } from "@/components/SkeletonRows";
import { EmptyState } from "@/components/EmptyState";
import { Pagination } from "@/components/Pagination";
import { useDebouncedValue } from "@/hooks/useDebouncedValue";
import { getApiErrorMessage } from "@/utils/errors";

const STATUS_STYLES: Record<string, string> = {
  active: "bg-emerald-50 text-emerald-700",
  inactive: "bg-amber-50 text-amber-700",
  archived: "bg-slate-100 text-slate-500",
};

export function ProjectsPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search);
  const [departmentId, setDepartmentId] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [departments, setDepartments] = useState<Department[]>([]);
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Paginated<Project> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listDepartments().then(setDepartments).catch(() => undefined);
  }, []);

  useEffect(() => {
    setIsLoading(true);
    setError(null);
    listProjects({
      q: debouncedSearch || undefined,
      department_id: departmentId || undefined,
      status: statusFilter || undefined,
      page,
      page_size: 10,
    })
      .then(setData)
      .catch((err) => setError(getApiErrorMessage(err, "Could not load projects.")))
      .finally(() => setIsLoading(false));
  }, [debouncedSearch, departmentId, statusFilter, page]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, departmentId, statusFilter]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-slate-900">Projects</h1>

      <div className="flex flex-wrap items-center gap-3">
        <SearchInput value={search} onChange={setSearch} placeholder="Search by name or key" />
        <select
          value={departmentId}
          onChange={(e) => setDepartmentId(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
        >
          <option value="">All departments</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
        >
          <option value="">All statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {isLoading && <SkeletonRows />}

      {!isLoading && error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">{error}</div>
      )}

      {!isLoading && !error && data && data.items.length === 0 && (
        <EmptyState title="No projects found" description="Try a different search term or filter." />
      )}

      {!isLoading && !error && data && data.items.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.items.map((p) => (
            <div
              key={p.id}
              onClick={() => navigate(`/projects/${p.id}`)}
              className="cursor-pointer rounded-xl border border-slate-200 bg-white p-4 transition-shadow hover:shadow-sm"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-400">{p.key}</p>
                </div>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_STYLES[p.status]}`}>
                  {p.status}
                </span>
              </div>
              {p.description && (
                <p className="mt-2 line-clamp-2 text-sm text-slate-500">{p.description}</p>
              )}
            </div>
          ))}
        </div>
      )}

      {!isLoading && !error && data && (
        <Pagination page={page} pageSize={10} total={data.total} onPageChange={setPage} />
      )}
    </div>
  );
}
