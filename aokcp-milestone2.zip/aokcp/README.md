# AI-Powered Organizational Knowledge Continuity Platform

An enterprise knowledge-continuity platform: it pulls organizational
knowledge from Jira, GitHub, uploaded documents, and HR/employee data, stores
it across PostgreSQL (system of record), Neo4j (relationship graph), and
ChromaDB (semantic vectors), and exposes a Hybrid RAG + Knowledge Graph AI
assistant (Google Gemini) for question answering, employee handovers, project
onboarding, and knowledge-gap detection.

> **Build status**: This is a milestone-driven build. See
> `IMPLEMENTATION_STATUS.md` for exactly what is implemented and verified
> right now versus what is planned. Nothing in that file is marked complete
> unless it actually works.

## Problem Statement

Organizations lose critical operational knowledge whenever an employee
leaves, transfers teams, or switches projects — architecture decisions, "who
knows what", unresolved issues, and tribal context live in people's heads and
scattered tools. This platform centralizes and structures that knowledge so
it survives personnel changes.

## Objectives

- Aggregate Jira issues, GitHub activity, documents, and HR data into one
  queryable substrate.
- Represent organizational relationships explicitly via a knowledge graph.
- Provide grounded, cited AI answers — never fabricated organizational facts.
- Automate handover and onboarding document generation.
- Surface knowledge concentration risk before it becomes a loss.

## Architecture

See `IMPLEMENTATION_PLAN.md` for the full architecture: entity models, graph
schema, vector collection design, the hybrid retrieval pipeline, and the
milestone plan.

```
React (Vite/TS) → FastAPI → PostgreSQL / Neo4j / ChromaDB
                          → Jira & GitHub (live or mock)
                          → Google Gemini (chat + embeddings)
```

## Technology Stack

**Backend**: Python 3.11, FastAPI, SQLAlchemy, Alembic, PostgreSQL, Pydantic,
JWT auth, passlib/bcrypt, httpx, Neo4j driver, ChromaDB client, Google GenAI
SDK, SentenceTransformers (embedding fallback), PyMuPDF, python-docx, pytest.

**Frontend**: React, Vite, TypeScript, Tailwind CSS, React Router, Axios,
Lucide React, Recharts.

**Infrastructure**: Docker Compose (PostgreSQL, Neo4j, ChromaDB, backend,
frontend), Alembic migrations.

## Project Structure

```
backend/
  app/
    api/routes/       REST endpoints (HTTP only, no business logic)
    core/              configuration
    db/                SQLAlchemy session + base model
    models/             ORM models
    schemas/           Pydantic request/response schemas
    repositories/       data access layer
    services/           business logic (auth, jira, github, graph, vector,
                          rag, gemini, handover, onboarding, documents, ...)
    auth/               password hashing, JWT, RBAC dependencies
    middleware/         global error handling
    seed.py             baseline + sample data loader
  alembic/              migrations
  tests/                pytest suite
frontend/
  src/
    components/         shared UI (route guards, empty/placeholder states)
    layouts/             app shell (sidebar, topbar)
    pages/                routed pages
    features/<domain>/   per-feature API calls + components
    contexts/             AuthContext
    services/             axios client
    types/                shared TS types
docker-compose.yml
.env.example
IMPLEMENTATION_PLAN.md
IMPLEMENTATION_STATUS.md
```

## Setup

### Prerequisites
Docker + Docker Compose (recommended), or locally: Python 3.11+, Node 20+,
PostgreSQL 16, Neo4j 5, ChromaDB.

### 1. Configure environment
```bash
cp .env.example .env
# edit .env — JWT_SECRET_KEY at minimum for anything beyond local demo use
```
Jira, GitHub, and Gemini credentials are optional. Leave them blank to run in
mock/local-embedding mode (see "Mock Mode" below).

### 2. Run with Docker Compose
```bash
docker compose up --build
```
This starts PostgreSQL, Neo4j, ChromaDB, the backend (auto-runs Alembic
migrations and the seed script on boot), and the frontend.

- Frontend: http://localhost:5173
- Backend API docs (Swagger): http://localhost:8000/api/v1/docs
- Health check: http://localhost:8000/api/v1/health
- Neo4j browser: http://localhost:7474

Default seeded admin account: `admin@aokcp.local` / `ChangeMe123!` — change
this immediately in any non-throwaway environment.

### 3. Run locally without Docker (backend)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env   # adjust DATABASE_URL etc. to localhost
alembic upgrade head
python -m app.seed
uvicorn app.main:app --reload
```

### 4. Run locally without Docker (frontend)
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

### Testing
```bash
cd backend
pytest -q
```
Tests run against an in-memory SQLite database and never require live Jira,
GitHub, Neo4j, ChromaDB, or Gemini credentials.

### Frontend build check
```bash
cd frontend
npm run build
```

## Mock Mode

Jira, GitHub, and Gemini all have mock/sample-data code paths so the full
pipeline is demonstrable with zero external credentials. Every API response
and UI element that reflects mock data is explicitly labeled `MOCK` (vs.
`LIVE`) — the system never silently presents mock data as real. Mock
providers land in Milestones 3 (Jira), 4 (GitHub), and are used by default
for Gemini embeddings (SentenceTransformers fallback) whenever
`GEMINI_API_KEY` is unset.

## Current Implementation Status

See `IMPLEMENTATION_STATUS.md` — updated after every milestone with what's
complete, in progress, and pending, plus known limitations.

## Known Limitations (current milestone)

- Only Milestones 1–2 (architecture, authentication, and core enterprise
  data — employees, departments, projects, tasks, bugs, documents,
  integration config, sync logs, audit logs) have working code so far;
  every other feature described in this README's target architecture is
  planned, not yet built — check the status file before assuming a feature
  exists.
- Retrieval-side entity/intent detection is planned to be lexical
  (name/key matching), not a trained NER model — a deliberate scope decision
  for an explainable academic project, documented in
  `IMPLEMENTATION_PLAN.md`.
- `pytest` / `npm run build` / `docker compose build` have not been executed
  in the authoring environment (no package-registry network access there);
  all backend Python files are confirmed syntactically valid
  (`python -m py_compile`). Run the commands above yourself to verify —
  they're expected to pass but have not been confirmed by the author.

## Future Enhancements

Full Jira/GitHub sync, Neo4j graph, ChromaDB retrieval, hybrid RAG, Gemini
assistant, handover/onboarding generation, and knowledge-gap detection per
the milestone plan in `IMPLEMENTATION_PLAN.md`.

## Screenshots

_To be added once the dashboard and core pages are built out (Milestone 2+)._
